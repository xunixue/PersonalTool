﻿using KCPExampleProto;
using KCPNet;

namespace KCPExampleClient;

///客户端session连接
public class ClientSession : KCPSession<NetMsg>
{
    protected override void OnConnected()
    {
    }

    protected override void OnReceiveMsg(NetMsg msg)
    {
        KCPTool.ColorLog(KCPLogColor.Magenta, "Sid:{0},RcvServer:{1}", m_sid, msg.info);
    }

    protected override void OnDisConnected()
    {
    }

    protected override void OnUpdate(DateTime now)
    {
    }
}