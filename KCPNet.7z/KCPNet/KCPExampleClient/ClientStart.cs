﻿using KCPExampleProto;
using KCPNet;

namespace KCPExampleClient;

///控制台客户端
public class ClientStart
{
    private static KCPNet<ClientSession, NetMsg> client;
    private static Task<bool> checkTask = null;

    private static void Main(string[] args)
    {
        var ip = "127.0.0.1";
        client = new KCPNet<ClientSession, NetMsg>();
        client.StartAsClient(ip, 17666);
        checkTask = client.ConnectServer(200, 5000);
        Task.Run(ConnectCheck);

        while (true)
        {
            var ipt = Console.ReadLine();
            if (ipt == "quit")
            {
                client.CloseClient();
                break;
            }
            else
            {
                client.clientSession.SendMsg(new NetMsg
                {
                    info = ipt
                });
            }
        }

        Console.ReadKey();
    }

    private static int counter = 0;

    private static async void ConnectCheck()
    {
        while (true)
        {
            await Task.Delay(3000);
            if (checkTask != null && checkTask.IsCompleted)
                if (checkTask.Result)
                {
                    KCPTool.ColorLog(KCPLogColor.Green, "ConnectServer Success.");
                    checkTask = null;
                    await Task.Run(SendPingMsg);
                }
                else
                {
                    ++counter;
                    if (counter > 4)
                    {
                        KCPTool.Error(string.Format("Connect Failed {0} Times,Check Your Network Connection.", counter));
                        checkTask = null;
                        break;
                    }
                    else
                    {
                        KCPTool.Warn(string.Format("Connect Failed {0} Times.Retry...", counter));
                        checkTask = client.ConnectServer(200, 5000);
                    }
                }
        }
    }

    private static async void SendPingMsg()
    {
        while (true)
        {
            await Task.Delay(5000);
            if (client != null && client.clientSession != null)
            {
                client.clientSession.SendMsg(new NetMsg
                {
                    cmd = CMD.NetPing,
                    netPing = new NetPing
                    {
                        isOver = false
                    }
                });
                KCPTool.ColorLog(KCPLogColor.Green, "Client Send Ping Message.");
            }
            else
            {
                KCPTool.ColorLog(KCPLogColor.Green, "Ping Task Cancel");
                break;
            }
        }
    }
}