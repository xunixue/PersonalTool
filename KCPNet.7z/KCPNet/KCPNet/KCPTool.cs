﻿//KCPNet网络库工具类

using System;
using System.IO;
using System.IO.Compression;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading;
using ProtoBuf;

namespace KCPNet;

public class KCPTool
{
    public static Action<string> LogFunc;
    public static Action<KCPLogColor, string> ColorLogFunc;
    public static Action<string> WarnFunc;
    public static Action<string> ErrorFunc;

    public static void Log(string msg, params object[] args)
    {
        msg = string.Format(msg, args);
        if (LogFunc != null)
            LogFunc(msg);
        else
            ConsoleLog(msg);
    }

    public static void ColorLog(KCPLogColor color, string msg, params object[] args)
    {
        msg = string.Format(msg, args);
        if (ColorLogFunc != null)
            ColorLogFunc(color, msg);
        else
            ConsoleLog(msg);
    }

    public static void Warn(string msg, params object[] args)
    {
        msg = string.Format(msg, args);
        if (WarnFunc != null)
            WarnFunc(msg);
        else
            ConsoleLog(msg, KCPLogColor.Yellow);
    }

    public static void Error(string msg, params object[] args)
    {
        msg = string.Format(msg, args);
        if (ErrorFunc != null)
            ErrorFunc(msg);
        else
            ConsoleLog(msg, KCPLogColor.Red);
    }

    private static void ConsoleLog(string msg, KCPLogColor color = KCPLogColor.None)
    {
        var threadID = Thread.CurrentThread.ManagedThreadId;
        msg = string.Format("Thread:{0} {1}", threadID, msg);

        switch (color)
        {
            case KCPLogColor.Red:
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine(msg);
                Console.ForegroundColor = ConsoleColor.Gray;
                break;
            case KCPLogColor.Green:
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine(msg);
                Console.ForegroundColor = ConsoleColor.Gray;
                break;
            case KCPLogColor.Blue:
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine(msg);
                Console.ForegroundColor = ConsoleColor.Gray;
                break;
            case KCPLogColor.Cyan:
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine(msg);
                Console.ForegroundColor = ConsoleColor.Gray;
                break;
            case KCPLogColor.Magenta:
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine(msg);
                Console.ForegroundColor = ConsoleColor.Gray;
                break;
            case KCPLogColor.Yellow:
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine(msg);
                Console.ForegroundColor = ConsoleColor.Gray;
                break;
            case KCPLogColor.None:
            default:
                Console.WriteLine(msg);
                break;
        }
    }

    public static byte[] Serialize<T>(T msg) where T : KCPMsg
    {
        using (var memoryStream = new MemoryStream())
        {
            try
            {
                Serializer.Serialize(memoryStream, msg);
                return memoryStream.ToArray();
            }
            catch (SerializationException e)
            {
                Error("Failed to serialize.Reason:{0}", e.Message);
                throw;
            }
        }
    }

    public static T DeSerialize<T>(byte[] bytes) where T : KCPMsg
    {
        using (var memoryStream = new MemoryStream(bytes))
        {
            try
            {
                return Serializer.Deserialize<T>(memoryStream);
            }
            catch (SerializationException e)
            {
                Error("Failed to Deserialize.Reason:{0} byte:{1}", e.Message, bytes.Length);
                throw;
            }
        }
    }

    public static byte[] Compress(byte[] input)
    {
        using (var outMS = new MemoryStream())
        {
            using (var gzs = new GZipStream(outMS, CompressionMode.Compress, true))
            {
                gzs.Write(input, 0, input.Length);
                gzs.Close();
                return outMS.ToArray();
            }
        }
    }

    public static byte[] DeCompress(byte[] input)
    {
        using (var inputMS = new MemoryStream(input))
        {
            using (var outMs = new MemoryStream())
            {
                using (var gzs = new GZipStream(inputMS, CompressionMode.Decompress))
                {
                    var bytes = new byte[1024];
                    var len = 0;
                    while ((len = gzs.Read(bytes, 0, bytes.Length)) > 0)
                        outMs.Write(bytes, 0, len);
                    gzs.Close();
                    return outMs.ToArray();
                }
            }
        }
    }

    private static readonly DateTime utcStart = new(1970, 1, 1);

    public static ulong GetUTCStartMilliseconds()
    {
        var ts = DateTime.UtcNow - utcStart;
        return (ulong)ts.TotalMilliseconds;
    }
}

public enum KCPLogColor
{
    None,
    Red,
    Green,
    Blue,
    Cyan,
    Magenta,
    Yellow
}