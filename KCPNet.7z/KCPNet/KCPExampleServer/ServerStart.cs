﻿using KCPExampleProto;
using KCPNet;

namespace KCPExampleServer;

/// .net core控制台服务端
public class ServerStart
{
    private static void Main(string[] args)
    {
        var ip = "127.0.0.1";
        var server = new KCPNet<ServerSession, NetMsg>();
        server.StartAsServer(ip, 17666);

        while (true)
        {
            var ipt = Console.ReadLine();
            if (ipt == "quit")
            {
                server.CloseServer();
                break;
            }
            else
            {
                server.BroadCastMsg(new NetMsg { info = ipt });
            }
        }

        Console.ReadKey();
    }
}