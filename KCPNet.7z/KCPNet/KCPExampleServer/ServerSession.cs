﻿using KCPExampleProto;
using KCPNet;

namespace KCPExampleServer;

///.net core服务端session连接
public class ServerSession : KCPSession<NetMsg>
{
    protected override void OnConnected()
    {
        KCPTool.ColorLog(KCPLogColor.Green, "Client Online,Sid:{0}", m_sid);
    }

    protected override void OnReceiveMsg(NetMsg msg)
    {
        KCPTool.ColorLog(KCPLogColor.Magenta, "Sid:{0},RcvClient,CMD:{1} {2}", m_sid, msg.cmd.ToString(), msg.info);

        if (msg.cmd == CMD.NetPing)
            if (msg.netPing.isOver)
            {
                CloseSession();
            }
            else
            {
                //收到ping请求,则重置检查计数，并回复ping消息到客户端
                checkCounter = 0;
                var pingMsg = new NetMsg
                {
                    cmd = CMD.NetPing,
                    netPing = new NetPing
                    {
                        isOver = false
                    }
                };
                SendMsg(pingMsg);
            }
    }

    private int checkCounter;
    private DateTime checkTime = DateTime.UtcNow.AddSeconds(5);

    protected override void OnDisConnected()
    {
        KCPTool.Warn("Client Offline,Sid:{0}", m_sid);
    }

    protected override void OnUpdate(DateTime now)
    {
        if (now > checkTime)
        {
            checkTime = now.AddSeconds(5);
            checkCounter++;
            if (checkCounter > 3)
            {
                var pingMsg = new NetMsg
                {
                    cmd = CMD.NetPing,
                    netPing = new NetPing { isOver = true }
                };
                OnReceiveMsg(pingMsg);
            }
        }
    }
}