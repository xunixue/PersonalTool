﻿using System;
using KCPNet;
using ProtoBuf;

///网络通信数据协议
namespace KCPExampleProto
{
    [ProtoContract]
    public class NetMsg : KCPMsg
    {
        [ProtoMember(1)] public CMD cmd;
        [ProtoMember(2)] public NetPing netPing;
        [ProtoMember(3)] public string info;
    }

    [ProtoContract]
    public class NetPing
    {
        //是否结束连接
        [ProtoMember(1)] public bool isOver;
    }

    public enum CMD
    {
        None,
        ReqLogin,
        NetPing
    }
}