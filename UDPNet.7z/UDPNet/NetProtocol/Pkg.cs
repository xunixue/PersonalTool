﻿using ProtoBuf;

namespace NetProtocol;

[ProtoContract]
public class Pkg
{
    [ProtoMember(1)] public Head head;
    [ProtoMember(2)] public Body body;
}

[ProtoContract]
public class Head
{
    [ProtoMember(1)] public CMD cmd;
    [ProtoMember(2)] public int seq;
    [ProtoMember(3)] public int error;
}

[ProtoContract]
public class Body
{
    [ProtoMember(1)] public ReqLogicLogin reqLogicLogin;
    [ProtoMember(2)] public RspLogicLogin rspLogicLogin;
    [ProtoMember(3)] public ReqBagInfo reqBagInfo;
    [ProtoMember(4)] public RspBagInfo rspBagInfo;
}

#region LogicLogin

[ProtoContract]
public class ReqLogicLogin
{
    [ProtoMember(1)] public string acct;
    [ProtoMember(2)] public string pass;
}

[ProtoContract]
public class RspLogicLogin()
{
    [ProtoMember(1)] public UserData userData;
}

[ProtoContract]
public class UserData
{
    [ProtoMember(1)] public int uid; //区服唯一ID；
    [ProtoMember(2)] public string name;
    [ProtoMember(3)] public int level;
    [ProtoMember(4)] public int exp;
}

#endregion

[ProtoContract]
public class ReqBagInfo
{
    //
}

[ProtoContract]
public class RspBagInfo
{
    [ProtoMember(1)] public List<BagItem> itemList;
}

[ProtoContract]
public class BagItem
{
    [ProtoMember(1)] public int id; //物品id
    [ProtoMember(2)] public int type; //物品类型
    [ProtoMember(3)] public string des; //物品描述
}

public enum Error
{
    db_data_error = 1,

    acct_data_error = 2001, //账号数据异常
    team_wait_enter = 2002, //排队等待进入
    bag_data_error = 2003 //背包数据异常
}

public enum CMD
{
    None = 0,
    LogicLogin = 1,
    BagInfo = 2
}