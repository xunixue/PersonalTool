﻿//常规序列化工具

using ProtoBuf;

namespace NetProtocol;

public static class ProtocolTools
{
    //序列化方法 使用protoBuf来序列化
    public static byte[] Serialize<T>(T obj) where T : class
    {
        using (var memoryStream = new MemoryStream())
        {
            try
            {
                Serializer.Serialize(memoryStream, obj);
                return memoryStream.ToArray();
            }
            catch (Exception e)
            {
                Console.WriteLine("Failed to serialize.Reason:" + e.Message);
                return null;
            }
        }
    }

    public static T DeSerialize<T>(byte[] data) where T : class
    {
        using (var memoryStream = new MemoryStream(data))
        {
            try
            {
                return Serializer.Deserialize<T>(memoryStream);
            }
            catch (Exception e)
            {
                Console.WriteLine("Failed to deserialize.Reason:" + e.Message + "  bytesLen:" + data.Length);
                return null;
            }
        }
    }
}