﻿using System.Net;
using System.Net.Sockets;
using NetProtocol;

namespace UDPClient;

public class GameRoot
{
    private UdpClient udp;
    private LoginHandler _loginHandler;
    private BagHandler _bagHandler;

    //服务端IP
    private IPEndPoint remotePoint;

    private static GameRoot instance;

    public static GameRoot Instance
    {
        get
        {
            if (instance == null)
                instance = new GameRoot();
            return instance;
        }
    }

    public void Init()
    {
        remotePoint = new IPEndPoint(IPAddress.Parse("127.0.01"), 17666);
        _loginHandler = new LoginHandler();
        _bagHandler = new BagHandler();
        //设置为0，则客户端发送端口由操作系统分配
        udp = new UdpClient(0);

        Task.Run(ClientReceive);
    }

    private async void ClientReceive()
    {
        UdpReceiveResult result;
        while (true)
        {
            result = await udp.ReceiveAsync();
            var data = result.Buffer;

            //服务端IP
            var srvIP = result.RemoteEndPoint;
            Console.WriteLine("Rcv Server Data From:" + srvIP);

            var pkg = ProtocolTools.DeSerialize<Pkg>(data);
            switch (pkg.head.cmd)
            {
                case CMD.None:
                    break;
                case CMD.LogicLogin:
                    _loginHandler.HandleLoginData(pkg.body.rspLogicLogin);
                    break;
                case CMD.BagInfo:
                    _bagHandler.HandleBagData(pkg.body.rspBagInfo);
                    break;
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }
    }

    public void ReqLogin()
    {
        var pkg = new Pkg
        {
            head = new Head
            {
                cmd = CMD.LogicLogin,
                seq = 1,
                error = 0
            },
            body = new Body
            {
                reqLogicLogin = new ReqLogicLogin
                {
                    acct = "Xue",
                    pass = "1111"
                }
            }
        };

        var bytes = ProtocolTools.Serialize(pkg);
        udp.Send(bytes, bytes.Length, remotePoint);
    }

    public void ReqBag()
    {
        var pkg = new Pkg
        {
            head = new Head
            {
                cmd = CMD.BagInfo,
                seq = 2,
                error = 0
            }
        };

        var bytes = ProtocolTools.Serialize(pkg);
        udp.Send(bytes, bytes.Length, remotePoint);
    }
}