﻿using NetProtocol;

namespace UDPClient;

public class BagHandler
{
    public void HandleBagData(RspBagInfo rsp)
    {
        var itemList = rsp.itemList;
        for (var i = 0; i < itemList.Count; i++)
        {
            Console.WriteLine("id:" + itemList[i].id);
            Console.WriteLine("type:" + itemList[i].type);
            Console.WriteLine("des:" + itemList[i].des);
            Console.WriteLine("----------------------");
        }
    }
}