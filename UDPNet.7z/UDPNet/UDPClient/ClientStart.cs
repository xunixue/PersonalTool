﻿namespace UDPClient;

internal class ClientStart
{
    private static void Main(string[] args)
    {
        Console.WriteLine("Client Start.");

        GameRoot.Instance.Init();

        while (true)
        {
            var ipt = Console.ReadLine();
            if (ipt == "login")
                GameRoot.Instance.ReqLogin();
            else if (ipt == "bag")
                GameRoot.Instance.ReqBag();
            else
                Console.WriteLine("Command undefined");
        }
    }
}