﻿//处理背包相关请求

using System.Net;
using NetProtocol;

namespace UDPServer;

public class BagHandler
{
    public void ReqBagInfo(Body reqBody, IPEndPoint pt)
    {
        Console.WriteLine("Client:{0} ReqBagInfo.", pt.ToString());

        var body = new Body
        {
            rspBagInfo = new RspBagInfo
            {
                itemList = new List<BagItem>()
            }
        };

        body.rspBagInfo.itemList.Add(new BagItem { id = 1, type = 0, des = "印度神油" });
        body.rspBagInfo.itemList.Add(new BagItem { id = 2, type = 0, des = "汇仁肾宝" });
        body.rspBagInfo.itemList.Add(new BagItem { id = 3, type = 1, des = "大力出奇迹" });

        ServerRoot.Instance.SendMsg(CMD.BagInfo, body, pt);
    }
}