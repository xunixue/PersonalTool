﻿//服务器根节点

using System.Net;
using System.Net.Sockets;
using NetProtocol;

namespace UDPServer;

public class ServerRoot
{
    private UdpClient udp;
    private LoginHandler _loginHandler;
    private BagHandler _bagHandler;

    private static ServerRoot instance;

    public static ServerRoot Instance
    {
        get
        {
            if (instance == null)
                instance = new ServerRoot();
            return instance;
        }
    }

    public void Init()
    {
        _loginHandler = new LoginHandler();
        _bagHandler = new BagHandler();
        udp = new UdpClient(new IPEndPoint(IPAddress.Parse("127.0.0.1"), 17666));

        Task.Run(ServerRecive);
    }

    private async void ServerRecive()
    {
        UdpReceiveResult result;
        while (true)
        {
            result = await udp.ReceiveAsync();
            var data = result.Buffer;

            //客户端IP
            var remotePoint = result.RemoteEndPoint;
            Console.WriteLine("Rcv Client Data From:" + remotePoint);

            var pkg = ProtocolTools.DeSerialize<Pkg>(data);
            switch (pkg.head.cmd)
            {
                case CMD.None:
                    break;
                case CMD.LogicLogin:
                    _loginHandler.ReqLogin(pkg.body, remotePoint);
                    break;
                case CMD.BagInfo:
                    _bagHandler.ReqBagInfo(pkg.body, remotePoint);
                    break;
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }
    }

    public void SendMsg(CMD cmd, Body body, IPEndPoint pt)
    {
        var pkg = new Pkg
        {
            head = new Head
            {
                cmd = cmd,
                seq = 6,
                error = 0
            },
            body = body
        };

        var bytes = ProtocolTools.Serialize(pkg);
        udp.Send(bytes, bytes.Length, pt);
    }
}