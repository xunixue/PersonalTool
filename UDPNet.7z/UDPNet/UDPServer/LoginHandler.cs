﻿//处理客户端登录请求

using System.Net;
using NetProtocol;

namespace UDPServer;

public class LoginHandler
{
    public void ReqLogin(Body reqBody, IPEndPoint pt)
    {
        var req = reqBody.reqLogicLogin;
        Console.WriteLine("Client:{0} ReqLogin,Acct:{1} Pass:{2}", pt.ToString(), req.acct, req.pass);

        var body = new Body
        {
            rspLogicLogin = new RspLogicLogin
            {
                userData = new UserData
                {
                    uid = 7,
                    name = "Xue",
                    level = 17,
                    exp = 27
                }
            }
        };

        ServerRoot.Instance.SendMsg(CMD.LogicLogin, body, pt);
    }
}