﻿namespace UDPServer;

internal class ServerStart
{
    private static void Main(string[] args)
    {
        Console.WriteLine("Server Start...");

        ServerRoot.Instance.Init();

        Console.ReadKey();
    }
}