﻿//Protobuf 基础使用

using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using LogUtils;
using ProtoBuf;

namespace BasicPB;

[ProtoContract]
internal class Person
{
    [ProtoMember(1)] public int Id { get; set; }
    [ProtoMember(2)] public string Name { get; set; }
    [ProtoMember(3)] public Address Address { get; set; }
}

[ProtoContract]
internal class Address
{
    [ProtoMember(1)] public string City { get; set; }
    [ProtoMember(2)] public string Street { get; set; }
}

internal class Program
{
    private static void Main(string[] args)
    {
        XLog.InitSettings();
        TestBasicPB();
        Console.ReadKey();
    }

    private static void TestBasicPB()
    {
        var person = new Person
        {
            Id = 12345,
            Name = "Xue",
            Address = new Address
            {
                City = "ShangHai",
                Street = "GuDai"
            }
        };
        byte[] bytes = null;
        using (var ms = new MemoryStream())
        {
            Serializer.Serialize(ms, person);
            bytes = new byte[ms.Length];
            Buffer.BlockCopy(ms.GetBuffer(), 0, bytes, 0, (int)ms.Length);
        }

        using (var ms = new MemoryStream(bytes))
        {
            var p = Serializer.Deserialize<Person>(ms);
            XLog.ColorLog(LogColor.Green, p.Id);
            XLog.ColorLog(LogColor.Green, p.Name);
            XLog.ColorLog(LogColor.Green, p.Address.City);
            XLog.ColorLog(LogColor.Green, p.Address.Street);
        }

        using (var file = File.Create("person.bytes"))
        {
            Serializer.Serialize(file, person);
        }


        using (var file = File.OpenRead("person.bytes"))
        {
            var newPerson = Serializer.Deserialize<Person>(file);

            XLog.ColorLog(LogColor.Green, newPerson.Id);
            XLog.ColorLog(LogColor.Green, newPerson.Name);
            XLog.ColorLog(LogColor.Green, newPerson.Address.City);
            XLog.ColorLog(LogColor.Green, newPerson.Address.Street);
        }
    }
}