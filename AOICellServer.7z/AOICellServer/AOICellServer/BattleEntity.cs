﻿using System.Numerics;
using XAOICell;
using AOICellProtocol;
using LogUtils;

namespace AOICellServer;

public enum PlayerStateEnum
{
    None = 0,
    Online = 1,
    Offline = 2,
    Mandate = 3
}

public class BattleEntity
{
    public uint entityID;
    public ServerSession session;
    public Vector3 targetDir;
    public Vector3 targetPos;
    public PlayerStateEnum playerStateEnum;
    public EntityDriverEnum driverEnum = EntityDriverEnum.None;

    public AOIEntity aoiEntity;

    public void OnEnterStage(BattleStage stage)
    {
        playerStateEnum = PlayerStateEnum.Online;
        this.ColorLog(LogColor.Cyan, $"entityID:{entityID} enter stage:{stage.cfg.stageID}");
    }

    public void OnExitStage()
    {
        playerStateEnum = PlayerStateEnum.Offline;
        this.ColorLog(LogColor.Cyan, $"entityID:{entityID} exit stage.");
    }

    public void OnUpdateStage(Pkg pkg)
    {
        if (playerStateEnum == PlayerStateEnum.Online) 
            SendMsg(pkg);
    }

    public void OnUpdateStage(byte[] bytes)
    {
        if (playerStateEnum == PlayerStateEnum.Online) 
            SendMsg(bytes);
    }

    public void SendMsg(Pkg pkg)
    {
        session?.SendMsg(pkg);
    }

    public void SendMsg(byte[] bytes)
    {
        session?.SendMsg(bytes);
    }
}