﻿//服务器入口

using LogUtils;

namespace AOICellServer;

internal class ServerStart
{
    private static void Main(string[] args)
    {
        XLog.InitSettings();
        var monsterCount = 0;

        Task.Run(() =>
        {
            ServerRoot.Instance.Init();
            while (true)
            {
                for (var i = 0; i < monsterCount; i++) 
                    ServerRoot.Instance.CreateServerEntity();
                monsterCount = 0;
                ServerRoot.Instance.Tick();
                Thread.Sleep(10);
            }
        });

        while (true)
        {
            var ipt = Console.ReadLine();
            if (int.TryParse(ipt, out var val))
                monsterCount = val;
            else
                XLog.Warn("输入不合法");
        }
    }
}