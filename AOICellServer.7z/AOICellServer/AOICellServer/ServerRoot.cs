﻿//服务器根节点

using System.Collections.Concurrent;
using System.Numerics;
using AOICellProtocol;
using PENet;
using XAOICell;

namespace AOICellServer;

public class ServerRoot
{
    private static ServerRoot instance;

    public static ServerRoot Instance
    {
        get
        {
            if (instance == null) instance = new ServerRoot();
            return instance;
        }
    }

    private AsyncNet<ServerSession, Pkg> server = new();
    private ConcurrentQueue<NetPack> packQue = new();
    private BattleStage stage = new();
    private Random rd = new();

    public void Init()
    {
        server.StartAsServer("127.0.0.1", 17666);
        stage.InitStage(101);
    }

    public void Tick()
    {
        while (!packQue.IsEmpty)
            if (packQue.TryDequeue(out var pack))
                switch (pack.Pkg.cmd)
                {
                    case Cmd.ReqLogin:
                        LoginStage(pack);
                        break;
                    case Cmd.SndMovePos:
                        stage.MoveEntity(pack.Pkg.sndMovePos);
                        break;
                    case Cmd.SndExit:
                        stage.Exit(pack.Pkg.sndExit.entityID);
                        break;
                    default:
                        break;
                }
            else
                this.Error($"Dequeue packQue fail.");

        stage.TickStage();
    }

    public void UnInit()
    {
        stage.UnInitStage();
    }

    public void AddMsgPack(NetPack pack)
    {
        packQue.Enqueue(pack);
    }

    public void CreateServerEntity()
    {
        float rdx = rd.Next(-CommonConfigs.borderX, CommonConfigs.borderX);
        float rdz = rd.Next(-CommonConfigs.borderZ, CommonConfigs.borderZ);

        var entity = new BattleEntity
        {
            entityID = GetServerUniqueEntityID(),
            targetPos = new Vector3(rdx, 0, rdz),
            playerStateEnum = PlayerStateEnum.None,
            driverEnum = EntityDriverEnum.Server
        };

        stage.EnterStage(entity);
    }

    private void LoginStage(NetPack pack)
    {
        var entity = new BattleEntity
        {
            entityID = GetClientUniqueEntityID(),
            session = pack.Session,
            targetPos = new Vector3(10, 0, 10),
            playerStateEnum = PlayerStateEnum.None,
            driverEnum = EntityDriverEnum.Client
        };

        stage.EnterStage(entity);

        entity.SendMsg(new Pkg
        {
            cmd = Cmd.RspLogin,
            rspLogin = new RspLogin
            {
                entityID = entity.entityID
            }
        });
    }

    private uint uid = 1000;

    private uint GetClientUniqueEntityID()
    {
        return ++uid;
    }

    private uint sid = 2000;

    private uint GetServerUniqueEntityID()
    {
        return ++sid;
    }
}