﻿//服务器会话管理

using AOICellProtocol;
using LogUtils;
using PENet;

namespace AOICellServer;

public class ServerSession : AsyncSession<Pkg>
{
    protected override void OnDisConnected()
    {
        this.ColorLog(LogColor.Green, "Client Offline.");
    }

    protected override void OnConnected(bool result)
    {
        this.ColorLog(LogColor.Green, "New Client Online");
    }

    protected override void OnReceiveMsg(Pkg pkg)
    {
        this.ColorLog(LogColor.Green, $"RcvClientMsg:{pkg.cmd.ToString()}");
        ServerRoot.Instance.AddMsgPack(new NetPack(this, pkg));
    }
}

public class NetPack
{
    public ServerSession Session;
    public Pkg Pkg;

    public NetPack(ServerSession session, Pkg pkg)
    {
        Session = session;
        Pkg = pkg;
    }
}