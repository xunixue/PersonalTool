﻿//战斗关卡

using System.Collections.Concurrent;
using System.Numerics;
using XAOICell;
using AOICellProtocol;
using LogUtils;
using PENet;

namespace AOICellServer;

public class StageConfig
{
    public int stageID;
    public string stageName;

    public int aoiSize;
    public int initCount = 100;
}

public class BattleStage
{
    public StageConfig cfg;
    public AOIMgr aoiMgr;

    private ConcurrentDictionary<uint, BattleEntity> entityDic = new();
    private ConcurrentQueue<BattleEntity> exitOPQue = new();
    private ConcurrentQueue<BattleEntity> enterOPQue = new();
    private ConcurrentQueue<BattleEntity> moveOPQue = new();

    public void InitStage(int stageID)
    {
        cfg = new StageConfig
        {
            stageID = stageID,
            stageName = "长安城",
            aoiSize = CommonConfigs.aoiSize,
            initCount = 200
        };
        var aoi_cfg = new AOIConfigs
        {
            MapName = cfg.stageName,
            CellSize = cfg.aoiSize,
            InitCount = cfg.initCount
        };

        aoiMgr = new AOIMgr(aoi_cfg)
        {
            OnEntityCellViewChange = EntityCellViewChange,
            OnCellEntityOpCombine = CellEntityOpCombine,

            OnCreateNewCell = (xIndex, zIndex) =>
            {
                var pkg = new Pkg
                {
                    cmd = Cmd.NtfCell,
                    ntfCell = new NtfCell
                    {
                        xIndex = xIndex,
                        zIndex = zIndex
                    }
                };

                foreach (var item in entityDic) item.Value.SendMsg(pkg);
            }
        };

        historyTime = DateTime.Now;
    }

    public void TickStage()
    {
        RandomServerAI();

        while (exitOPQue.TryDequeue(out var entity))
        {
            aoiMgr.ExitCell(entity.aoiEntity);
            if (entityDic.TryRemove(entity.entityID, out var e))
            {
                entity.OnExitStage();
                entity.aoiEntity = null;
            }
            else
            {
                this.Error($"entity:{entity.entityID} is not exist in entityDic");
            }
        }

        while (enterOPQue.TryDequeue(out var entity))
        {
            entity.aoiEntity = aoiMgr.EnterCell(entity.entityID, entity.targetPos.X, entity.targetPos.Z, entity.driverEnum);
            if (!entityDic.ContainsKey(entity.entityID))
            {
                if (entityDic.TryAdd(entity.entityID, entity))
                {
                    entity.OnEnterStage(this);


                    foreach (var item in aoiMgr.GetExistCellDic())
                    {
                        var pkg = new Pkg
                        {
                            cmd = Cmd.NtfCell,
                            ntfCell = new NtfCell
                            {
                                xIndex = item.Value.xIndex,
                                zIndex = item.Value.zIndex
                            }
                        };

                        entity.SendMsg(pkg);
                    }
                }
                else
                {
                    this.Error($"entity:{entity.entityID} is exist in entityDic");
                }
            }
            else
            {
                this.Error($"entity:{entity.entityID} is  exist in stage:{cfg.stageID} {cfg.stageName}");
            }
        }

        while (moveOPQue.TryDequeue(out var entity)) aoiMgr.UpdatePos(entity.aoiEntity, entity.targetPos.X, entity.targetPos.Z);

        aoiMgr.CalcAOIUpdate();
    }

    public void UnInitStage()
    {
        entityDic.Clear();
        exitOPQue.Clear();
        enterOPQue.Clear();
        moveOPQue.Clear();
        cfg = null;
        aoiMgr = null;
    }

    public void EnterStage(BattleEntity entity)
    {
        this.Log($"entityID:{entity.entityID} enter stage:{cfg.stageName}");
        if (!entityDic.ContainsKey(entity.entityID))
            enterOPQue.Enqueue(entity);
        else
            this.Warn($"entity:{entity.entityID} is exist in stage:{cfg.stageID} {cfg.stageName}");
    }

    public void UpdateStage(BattleEntity entity)
    {
        if (entityDic.ContainsKey(entity.entityID))
            moveOPQue.Enqueue(entity);
        else
            this.Warn($"entity:{entity.entityID} is not exist in stage:{cfg.stageID} {cfg.stageName}");
    }

    public void ExitStage(BattleEntity entity)
    {
        if (entityDic.ContainsKey(entity.entityID))
            exitOPQue.Enqueue(entity);
        else
            this.Warn($"entity:{entity.entityID} is not exist in stage:{cfg.stageID} {cfg.stageName}");
    }

    public void MoveEntity(SndMovePos snd)
    {
        if (entityDic.TryGetValue(snd.entityID, out var entity))
        {
            entity.targetPos = new Vector3(snd.PosX, 0, snd.PosZ);
            UpdateStage(entity);
        }
    }

    public void Exit(uint entityID)
    {
        if (entityDic.TryGetValue(entityID, out var entity)) ExitStage(entity);
    }

    private void EntityCellViewChange(AOIEntity ae, UpdateItem item)
    {
        var pkg = new Pkg
        {
            cmd = Cmd.NtfAOIMsg,
            ntfAOIMsg = new NtfAOIMsg
            {
                enterLst = new List<EnterMsg>(),
                exitLst = new List<ExitMsg>()
            }
        };

        if (item.enterLst.Count > 0)
            for (var i = 0; i < item.enterLst.Count; i++)
            {
                pkg.ntfAOIMsg.enterLst.Add(new EnterMsg
                {
                    entityID = item.enterLst[i].id,
                    PosX = item.enterLst[i].x,
                    PosZ = item.enterLst[i].z
                });

                this.Log($"AOI 1->{ae.entityID} Enter:{item.enterLst[i].id} x:{item.enterLst[i].x} z:{item.enterLst[i].z}");
            }

        if (item.exitLst.Count > 0)
            for (var i = 0; i < item.exitLst.Count; i++)
                pkg.ntfAOIMsg.exitLst.Add(new ExitMsg
                {
                    entityID = item.exitLst[i].id
                });

        if (entityDic.TryGetValue(ae.entityID, out var entity)) entity.OnUpdateStage(pkg);
    }

    private void CellEntityOpCombine(AOICell cell, UpdateItem item)
    {
        var pkg = new Pkg
        {
            cmd = Cmd.NtfAOIMsg,
            ntfAOIMsg = new NtfAOIMsg
            {
                enterLst = new List<EnterMsg>(),
                exitLst = new List<ExitMsg>(),
                moveLst = new List<MoveMsg>()
            }
        };
        if (item.enterLst.Count > 0)
            for (var i = 0; i < item.enterLst.Count; i++)
            {
                pkg.ntfAOIMsg.enterLst.Add(new EnterMsg
                {
                    entityID = item.enterLst[i].id,
                    PosX = item.enterLst[i].x,
                    PosZ = item.enterLst[i].z
                });
                this.Log($"AOI 0 ->cell:{cell.xIndex} {cell.zIndex}Enter:{item.enterLst[i].id} x:{item.enterLst[i].x} z:{item.enterLst[i].z}");
            }

        if (item.moveLst.Count > 0)
            for (var i = 0; i < item.moveLst.Count; i++)
                pkg.ntfAOIMsg.moveLst.Add(new MoveMsg
                {
                    entityID = item.moveLst[i].id,
                    PosX = item.moveLst[i].x,
                    PosZ = item.moveLst[i].z
                });
        if (item.exitLst.Count > 0)
            for (var i = 0; i < item.exitLst.Count; i++)
                pkg.ntfAOIMsg.exitLst.Add(new ExitMsg
                {
                    entityID = item.exitLst[i].id
                });

        var bytes = AsyncTool.PackLenInfo(AsyncTool.Serialize(pkg));

        foreach (var hs in cell.holdSet)
            if (entityDic.TryGetValue(hs.entityID, out var entity))
                entity.OnUpdateStage(bytes);
    }

    private Random rd = new();
    private DateTime historyTime;
    private DateTime lastTickDate = DateTime.Now;

    private void RandomServerAI()
    {
        if (DateTime.Now > lastTickDate.AddSeconds(CommonConfigs.randomDirInterval))
        {
            lastTickDate = DateTime.Now;

            foreach (var item in entityDic)
            {
                var entity = item.Value;
                if (entity.driverEnum == EntityDriverEnum.Server && rd.Next(0, 100) < CommonConfigs.randomDirRate)
                {
                    if (Math.Abs(entity.targetPos.X) >= CommonConfigs.borderX || Math.Abs(entity.targetPos.Z) >= CommonConfigs.borderZ)
                    {
                        float rdx = rd.Next(-CommonConfigs.borderX, CommonConfigs.borderX);
                        float rdz = rd.Next(-CommonConfigs.borderZ, CommonConfigs.borderZ);
                        entity.targetDir = Vector3.Normalize(new Vector3(rdx, 0, rdz) * 0.9f - entity.targetPos);
                    }
                    else
                    {
                        float rdx = rd.Next(-100, 100);
                        float rdz = rd.Next(-100, 100);
                        entity.targetDir = Vector3.Normalize(new Vector3(rdx == 0 ? 1 : rdx, 0, rdz == 0 ? 1 : rdz));
                    }
                }
            }
        }

        var now = DateTime.Now;
        var delta = (float)((now - historyTime).TotalMilliseconds / 1000);
        historyTime = now;
        foreach (var item in entityDic)
        {
            var entity = item.Value;
            if (entity.driverEnum == EntityDriverEnum.Server)
            {
                entity.targetPos += entity.targetDir * CommonConfigs.moveSpeed * delta;
                UpdateStage(entity);
            }
        }
    }
}