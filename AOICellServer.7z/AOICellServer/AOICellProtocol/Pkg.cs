﻿using System;
using System.Collections.Generic;
using PENet;

namespace AOICellProtocol
{
    /*
     * 1.宫格自适应生成，角色能走到的地方才生成
     * 2.宫格核心算法实现，确保角色相互可见或不可见，边界移动视野迁移（包括斜向移动）
     * 3.宫格计算结果合并复用，优化CPU开销（大部分情况下角色没有进行穿越边界，宫格内部视野是一样的变化情况，可以优化序列数据）
     * 4.剔除网无客户端关注宫格内的服务端逻辑实体AOI数据变化计算(比如服务端驱动的AI怪物产生的信息)
     */

    //算法核心思路:
    //存量增删(只算九宫格视野，然后其他角色移动数据先不算)，增量叠加（计算其他角色移动数据）

    public class CommonConfigs
    {
        public const int aoiSize = 50;
        public const float moveSpeed = 40;

        public const int borderX = 500;
        public const int borderZ = 500;

        public const int randomDirInterval = 1;
        public const int randomDirRate = 30;
    }

    public enum Cmd
    {
        ReqLogin,
        RspLogin,

        NtfCell,
        NtfAOIMsg,

        SndMovePos,
        SndExit
    }

    [Serializable]
    public class Pkg : AsyncMsg
    {
        public Cmd cmd;

        public ReqLogin reqLogin;
        public RspLogin rspLogin;
        public NtfCell ntfCell;

        public NtfAOIMsg ntfAOIMsg;
        public SndMovePos sndMovePos;
        public SndExit sndExit;
    }

    [Serializable]
    public class ReqLogin
    {
        public string acct;
    }

    [Serializable]
    public class RspLogin
    {
        public uint entityID;
    }

    [Serializable]
    public class NtfAOIMsg
    {
        public int type;
        public List<EnterMsg> enterLst;
        public List<MoveMsg> moveLst;
        public List<ExitMsg> exitLst;

        public override string ToString()
        {
            var content = "";
            if (enterLst != null)
                for (var i = 0; i < enterLst.Count; i++)
                {
                    var em = enterLst[i];
                    content += $"Enter:{em.entityID} {em.PosX},{em.PosZ}\n";
                }

            if (moveLst != null)
                for (var i = 0; i < moveLst.Count; i++)
                {
                    var mm = moveLst[i];
                    content += $"Move:{mm.entityID} {mm.PosX},{mm.PosZ}\n";
                }

            if (exitLst != null)
                for (var i = 0; i < exitLst.Count; i++)
                {
                    var mm = exitLst[i];
                    content += $"Exit:{mm.entityID}\n";
                }

            return content;
        }
    }

    [Serializable]
    public class EnterMsg
    {
        public uint entityID;
        public float PosX;
        public float PosZ;
    }

    [Serializable]
    public class MoveMsg
    {
        public uint entityID;
        public float PosX;
        public float PosZ;
    }

    [Serializable]
    public class ExitMsg
    {
        public uint entityID;
    }

    [Serializable]
    public class NtfCell
    {
        public int xIndex;
        public int zIndex;
    }

    [Serializable]
    public class SndMovePos
    {
        public uint entityID;
        public float PosX;
        public float PosZ;
    }

    [Serializable]
    public class SndExit
    {
        public uint entityID;
    }
}