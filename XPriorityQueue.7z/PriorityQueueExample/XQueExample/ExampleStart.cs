﻿using System;
using System.Collections.Generic;
using System.Threading;
using XUtils;

namespace PriorityQueueExample
{
    public class Item : IComparable<Item>
    {
        public string ItemName;
        public float Priority;

        public int CompareTo(Item other)
        {
            if (Priority < other.Priority)
                return -1;
            if (Priority > other.Priority)
                return 1;
            return 0;
        }

        public void PrintInfo()
        {
            Console.WriteLine($"ItemName:{ItemName}  Priority:{Priority}");
        }
    }

    internal class PEQueStartmm
    {
        public static void Main(string[] args)
        {
            //var count = 1000000;
            //LoopTest();

            var cts = new CancellationTokenSource();
            var thread = new Thread(DoWorkWithCancellation);

            // 将 CancellationToken 传递给线程  
            thread.Start(cts.Token);

            // 模拟工作一段时间然后取消  
            Thread.Sleep(2000);
            cts.Cancel();

            // 等待线程完成（注意：这只是一个简单的等待示例，实际中可能需要更复杂的同步机制）  
            thread.Join();

            Console.WriteLine("程序结束");

            thread.Start(cts.Token);
            Thread.Sleep(2000);
            cts.Cancel();
        }

        private static void DoWorkWithCancellation(object obj)
        {
            var token = (CancellationToken)obj;

            try
            {
                while (!token.IsCancellationRequested)
                {
                    // 模拟工作  
                    Thread.Sleep(100);
                    Console.WriteLine("线程正在工作...");
                }

                // 清理工作（如果需要）  
                Console.WriteLine("线程已停止工作");
            }
            catch (OperationCanceledException)
            {
                // 如果在任务中有异步操作（如 Task.Delay），可能会抛出 OperationCanceledException  
                // 但在这个简单的同步示例中，我们不会直接抛出它  
                Console.WriteLine("操作被取消");
            }
        }

        private static void LoopTest()
        {
            var rd = new Random();
            var genCount = rd.Next(100, 9999);
            var itemList = new List<Item>(genCount);
            for (var i = 0; i < genCount; i++)
                itemList.Add(new Item
                {
                    ItemName = i.ToString(),
                    Priority = rd.Next(0, 10000)
                });

            var peQue = new PEQue<Item>();
            for (var i = 0; i < itemList.Count; i++) peQue.Enqueue(itemList[i]);

            var rmvCount = rd.Next(1, 9999);
            for (var i = 0; i < rmvCount; i++)
            {
                var index = rd.Next(0, peQue.Count);
                var pqIndex = peQue.IndexOf(itemList[index]);
                if (pqIndex >= 0) peQue.RemoveAt(pqIndex);
            }

            var outList = new List<Item>();
            while (peQue.Count > 0)
            {
                var item = peQue.Dequeue();
                outList.Add(item);
                item.PrintInfo();
            }

            for (var i = 0; i < outList.Count; i++)
                if (i < outList.Count - 1)
                    if (outList[i].Priority > outList[i + 1].Priority)
                    {
                        var exception = new Exception("优先级异常");
                        throw exception;
                    }
        }
    }
}