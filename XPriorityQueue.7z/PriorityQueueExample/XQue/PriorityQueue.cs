﻿using System;
using System.Collections.Generic;

namespace XUtils
{
    public class PEQue<T> where T : IComparable<T>
    {
        public List<T> List;

        public PEQue(int capacity = 4)
        {
            List = new List<T>(capacity);
        }

        public int Count => List.Count;

        /// <summary>
        ///     进队列
        /// </summary>
        public void Enqueue(T item)
        {
            List.Add(item);
            var childIndex = List.Count - 1;
            HeapFiyUp(childIndex);
        }

        /// <summary>
        ///     出队列
        /// </summary>
        /// <returns></returns>
        public T Dequeue()
        {
            if (List.Count == 0) return default;

            var Item = List[0];
            var endIndex = List.Count - 1;
            List[0] = List[endIndex];
            List.RemoveAt(endIndex);
            endIndex--;
            HeapFiyDown(0, endIndex);

            return Item;
        }

        public T Peek()
        {
            return List.Count > 0 ? List[0] : default;
        }

        public int IndexOf(T t)
        {
            return List.IndexOf(t);
        }

        public T RemoveAt(int rmvIndex)
        {
            if (List.Count < rmvIndex)
                return default;
            var item = List[rmvIndex];
            var endIndex = List.Count - 1;
            List[rmvIndex] = List[endIndex];
            List.RemoveAt(endIndex);
            --endIndex;
            if (rmvIndex < endIndex)
            {
                var parentIndex = (rmvIndex - 1) / 2;
                if (parentIndex > 0 && List[rmvIndex].CompareTo(List[parentIndex]) < 0)
                    HeapFiyUp(rmvIndex);
                else
                    HeapFiyDown(rmvIndex, endIndex);
            }

            return item;
        }

        public T RemoveItem(T t)
        {
            var index = IndexOf(t);
            return index != -1 ? RemoveAt(index) : default;
        }

        public void Clear()
        {
            List.Clear();
        }

        public bool Contains(T t)
        {
            return List.Contains(t);
        }

        public bool IsEmpty()
        {
            return List.Count == 0;
        }

        public List<T> ToList()
        {
            return List;
        }

        public T[] ToArray()
        {
            return List.ToArray();
        }

        private void HeapFiyUp(int childIndex)
        {
            var parentIndex = (childIndex - 1) / 2;
            while (childIndex > 0 && List[childIndex].CompareTo(List[parentIndex]) < 0)
            {
                Swap(childIndex, parentIndex);
                childIndex = parentIndex;
                parentIndex = (childIndex - 1) / 2;
            }
        }

        private void HeapFiyDown(int topIndex, int endIndex)
        {
            while (true)
            {
                var minIndex = topIndex;
                //Left
                var childIndex = topIndex * 2 + 1;
                if (childIndex <= endIndex && List[childIndex].CompareTo(List[topIndex]) < 0)
                    minIndex = childIndex;
                //Right
                childIndex = topIndex * 2 + 2;
                if (childIndex <= endIndex && List[childIndex].CompareTo(List[minIndex]) < 0)
                    minIndex = childIndex;

                if (topIndex == minIndex)
                    break;

                Swap(topIndex, minIndex);
                topIndex = minIndex;
            }
        }

        private void Swap(int a, int b)
        {
            (List[a], List[b]) = (List[b], List[a]);
        }
    }
}