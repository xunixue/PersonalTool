﻿using System.Collections.Generic;

namespace XUtils
{
    public class Heap
    {
        public List<int> List;

        public Heap(int capacity = 4)
        {
            List = new List<int>(capacity);
        }

        /// <summary>
        ///     用整数示例，添加一个节点到当前堆中
        /// </summary>
        /// <param name="value"></param>
        public void AddNode(int value)
        {
            List.Add(value);
            var childIndex = List.Count - 1;
            var parentIndex = (childIndex - 1) / 2;
            while (childIndex > 0 && List[childIndex] < List[parentIndex])
            {
                Swap(childIndex, parentIndex);
                childIndex = parentIndex;
                parentIndex = (childIndex - 1) / 2;
            }
        }

        /// <summary>
        ///     移除堆顶元素
        /// </summary>
        /// <returns></returns>
        public int RemoveNode()
        {
            if (List.Count == 0) return int.MinValue;

            var value = List[0];
            var endIndex = List.Count - 1;
            List[0] = List[endIndex];
            List.RemoveAt(endIndex);
            endIndex--;
            var topIndex = 0;
            while (true)
            {
                var minIndex = topIndex;
                //Left
                var childIndex = topIndex * 2 + 1;
                if (childIndex <= endIndex && List[childIndex] < List[topIndex])
                    minIndex = childIndex;
                //Right
                childIndex = topIndex * 2 + 2;
                if (childIndex <= endIndex && List[childIndex] < List[minIndex])
                    minIndex = childIndex;

                if (topIndex == minIndex)
                    break;

                Swap(topIndex, minIndex);
                topIndex = minIndex;
            }

            return value;
        }

        private void Swap(int a, int b)
        {
            (List[a], List[b]) = (List[b], List[a]);
        }
    }
}