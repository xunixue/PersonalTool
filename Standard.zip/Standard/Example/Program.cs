﻿using XMath;

namespace Example;

internal class Program
{
    private static void Main(string[] args)
    {
        Example5();

        Console.ReadKey();
    }

    private static void Example5()
    {
        var v = new XVector3(2, 2, 2);
        Console.WriteLine("a:" + v.normalized);
        Console.WriteLine("b:" + XVector3.Normalize(v));
        v.Normalize();
        Console.WriteLine("c:" + v);
    }

    private static void Example4()
    {
        var v = new XVector3(2, 2, 2);
        Console.WriteLine(v.magnitude);
        XInt val = 4;
        Console.WriteLine(XCalc.Sqrt(val));
    }

    private static void Example3()
    {
        var hp = 500;
        var val1 = hp * new XInt(0.3f);
        Console.WriteLine("before scale: " + val1.ScaledValue);
        Console.WriteLine("before float: " + val1.RawFloat);
        Console.WriteLine("before int: " + val1.RawInt);

        var val2 = hp * new XInt(-0.3f);
        Console.WriteLine("after scale: " + val2.ScaledValue);
        Console.WriteLine("after float: " + val2.RawFloat);
        Console.WriteLine("after int: " + val2.RawInt);
    }

    private static void Example2()
    {
        var val1 = new XInt(1);
        var val2 = new XInt(1.5f);
        Console.WriteLine((val1 + val2).ToString());
        Console.WriteLine((val1 - val2).ToString());
        Console.WriteLine((val1 * val2).ToString());

        var val3 = new XInt(2);
        var val4 = new XInt(0.5f);
        Console.WriteLine((val3 / val4).ToString());
    }

    private static void Example1()
    {
        var val1 = new XInt(1);
        var val2 = new XInt(0.5f);

        if (val1 > val2)
            Console.WriteLine(true);
        else
            Console.WriteLine(false);

        var val3 = val1 << 1;
        Console.WriteLine(val3.ToString());

        XInt val4 = 1;
        var val5 = (XInt)0.5f;
    }
}