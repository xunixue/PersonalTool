﻿//运算参数

using System;

namespace XMath
{
    public class XArgs
    {
        public int value;
        public uint multipler;

        public XArgs(int value, uint multipler)
        {
            this.value = value;
            this.multipler = multipler;
        }

        public static XArgs Zero = new XArgs(0, 10000);
        public static XArgs HALFPI = new XArgs(15708, 10000);
        public static XArgs PI = new XArgs(31416, 10000);
        public static XArgs TWOPI = new XArgs(62832, 10000);

        public static bool operator >(XArgs a, XArgs b)
        {
            if (a.multipler == b.multipler)
                return a.value > b.value;
            else
                throw new Exception("multipler is unequal.");
        }

        public static bool operator <(XArgs a, XArgs b)
        {
            if (a.multipler == b.multipler)
                return a.value < b.value;
            else
                throw new Exception("multipler is unequal.");
        }

        public static bool operator >=(XArgs a, XArgs b)
        {
            if (a.multipler == b.multipler)
                return a.value >= b.value;
            else
                throw new Exception("multipler is unequal.");
        }

        public static bool operator <=(XArgs a, XArgs b)
        {
            if (a.multipler == b.multipler)
                return a.value <= b.value;
            else
                throw new Exception("multipler is unequal.");
        }

        public static bool operator ==(XArgs a, XArgs b)
        {
            if (a.multipler == b.multipler)
                return a.value == b.value;
            else
                throw new Exception("multipler is unequal.");
        }

        public static bool operator !=(XArgs a, XArgs b)
        {
            if (a.multipler == b.multipler)
                return a.value != b.value;
            else
                throw new Exception("multipler is unequal.");
        }

        /// 转为视图角度,不再用于逻辑运算
        public int CovertViewAngle()
        {
            var radians = ConvertToFloat();
            return (int)Math.Round(radians / Math.PI * 180);
        }

        /// 转为视图弧度，不可在用于逻辑运算
        public float ConvertToFloat()
        {
            return value * 1.0f / multipler;
        }

        public override bool Equals(object obj)
        {
            return obj is XArgs args && value == args.value && multipler == args.multipler;
        }

        public override int GetHashCode()
        {
            return value.GetHashCode();
        }

        public override string ToString()
        {
            return $"value:{value} multipler:{multipler}";
        }
    }
}