﻿//常用定点数数学运算

using System;

namespace XMath
{
    public class XCalc
    {
        public static XInt Sqrt(XInt value, int interator = 8)
        {
            if (value == XInt.Zero)
                return 0;

            if (value < XInt.Zero)
                throw new Exception();
            var result = value;
            XInt history;
            var count = 0;
            do
            {
                history = result;
                result = (result + value / result) >> 1;
                count++;
            } while (result != history && count < interator);

            return result;
        }

        public static XArgs Acos(XInt value)
        {
            var rate = value * AcosTable.HalfIndexCount + AcosTable.HalfIndexCount;
            rate = Clamp(rate, XInt.Zero, AcosTable.IndexCount);
            var rad = AcosTable.table[rate.RawInt];
            return new XArgs(AcosTable.table[rate.RawInt], AcosTable.Multipler);
        }

        public static XInt Clamp(XInt input, XInt min, XInt max)
        {
            if (input < min)
                return min;

            if (input > max)
                return max;

            return input;
        }
    }
}