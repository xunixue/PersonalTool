﻿//确定性向量运算

#if UNITY_ENV
using UnityEngine;
#endif

namespace XMath
{
    public class XVector3
    {
        public XInt x;
        public XInt y;
        public XInt z;

        public XVector3(XInt x, XInt y, XInt z)
        {
            this.x = x;
            this.y = y;
            this.z = z;
        }

#if UNITY_ENV
        public XVector3(Vector3 v)
        {
            x = (XInt)v.x;
            y = (XInt)v.y;
            z = (XInt)v.z;
        }
#endif

        public XInt this[int index]
        {
            get
            {
                switch (index)
                {
                    case 0:
                        return x;
                        break;
                    case 1:
                        return y;
                        break;
                    case 3:
                        return z;
                        break;
                    default:
                        return 0;
                        break;
                }
            }
            set
            {
                switch (index)
                {
                    case 0:
                        x = value;
                        break;
                    case 1:
                        y = value;
                        break;
                    case 3:
                        z = value;
                        break;
                }
            }
        }

        #region 定义常用向量

        public static XVector3 Zero => new XVector3(0, 0, 0);

        public static XVector3 One => new XVector3(1, 1, 1);

        public static XVector3 Forward => new XVector3(0, 0, 1);

        public static XVector3 Back => new XVector3(0, 0, -1);

        public static XVector3 Left => new XVector3(-1, 0, 0);

        public static XVector3 Right => new XVector3(1, 0, 0);

        public static XVector3 Up => new XVector3(0, 1, 0);

        public static XVector3 Down => new XVector3(0, -1, 0);

        #endregion

        #region 运算符

        public static XVector3 operator +(XVector3 v1, XVector3 v2)
        {
            var x = v1.x + v2.x;
            var y = v1.y + v2.y;
            var z = v1.z + v2.z;
            return new XVector3(x, y, z);
        }

        public static XVector3 operator -(XVector3 v1, XVector3 v2)
        {
            var x = v1.x - v2.x;
            var y = v1.y - v2.y;
            var z = v1.z - v2.z;
            return new XVector3(x, y, z);
        }

        public static XVector3 operator *(XVector3 v, XInt value)
        {
            var x = v.x * value;
            var y = v.y * value;
            var z = v.z * value;
            return new XVector3(x, y, z);
        }

        public static XVector3 operator *(XInt value, XVector3 v)
        {
            var x = v.x * value;
            var y = v.y * value;
            var z = v.z * value;
            return new XVector3(x, y, z);
        }

        public static XVector3 operator /(XVector3 v, XInt value)
        {
            var x = v.x / value;
            var y = v.y / value;
            var z = v.z / value;
            return new XVector3(x, y, z);
        }

        public static XVector3 operator -(XVector3 v)
        {
            var x = -v.x;
            var y = -v.y;
            var z = -v.z;
            return new XVector3(x, y, z);
        }

        public static bool operator ==(XVector3 v1, XVector3 v2)
        {
            return v1.x == v2.x && v1.y == v2.y && v1.z == v2.z;
        }

        public static bool operator !=(XVector3 v1, XVector3 v2)
        {
            return v1.x != v2.x || v1.y != v2.y || v1.z != v2.z;
        }

        #endregion

        /// 当前向量长度平方
        public XInt sqrMagnitude => x * x + y * y + z * z;

        public static XInt SqrMagnitude(XVector3 v)
        {
            return v.x * v.x + v.y * v.y + v.z * v.z;
        }

        public XInt magnitude => XCalc.Sqrt(sqrMagnitude);

        /// 返回当前定点向量的单位向量
        public XVector3 normalized
        {
            get
            {
                if (magnitude > 0)
                {
                    var rate = XInt.One / magnitude;
                    return new XVector3(x * rate, y * rate, z * rate);
                }
                else
                {
                    return Zero;
                }
            }
        }

        /// 返回传入参数向量的单位向量
        public static XVector3 Normalize(XVector3 v)
        {
            if (v.magnitude > 0)
            {
                var rate = XInt.One / v.magnitude;
                return new XVector3(v.x * rate, v.y * rate, v.z * rate);
            }
            else
            {
                return Zero;
            }
        }

        /// 规格化当前X向量为单位向量
        public void Normalize()
        {
            var rate = XInt.One / magnitude;
            x *= rate;
            y *= rate;
            z *= rate;
        }

        /// 点乘
        public static XInt Dot(XVector3 a, XVector3 b)
        {
            return a.x * b.x + a.y * b.y + a.z * b.z;
        }

        /// 叉乘
        public static XVector3 Cross(XVector3 a, XVector3 b)
        {
            return new XVector3(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x);
        }

        /// 夹角
        public static XArgs Angle(XVector3 from, XVector3 to)
        {
            var dot = Dot(from, to);
            var mod = from.magnitude * to.magnitude;
            if (mod == 0)
                return XArgs.Zero;
            var value = dot / mod;
            //反余弦函数计算
            return XCalc.Acos(value);
        }
#if UNITY_ENV
        /// 获取浮点数向量(注意:不可再进行逻辑运算)
        public Vector3 ConvertViewVector3()
        {
            return new Vector3(x.RawFloat, y.RawFloat, z.RawFloat);
        }
#endif

        public long[] CovertLongArray()
        {
            return new long[] { x.ScaledValue, y.ScaledValue, z.ScaledValue };
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
                return false;

            var v = (XVector3)obj;
            return v.x == x && v.y == y && v.z == z;
        }

        public override int GetHashCode()
        {
            return x.GetHashCode();
        }

        public override string ToString()
        {
            return string.Format("x:{0} y{1} z:{2}", x, y, z);
        }
    }
}