﻿//定点数

using System;

namespace XMath
{
    public class XInt
    {
        private long scaledValue;

        public long ScaledValue
        {
            get => scaledValue;
            set => scaledValue = value;
        }

        //移位计数
        private const int BIT_MOVE_COUNT = 10;
        private const long MULTIPLIER_FACTOR = 1 << BIT_MOVE_COUNT;

        public static readonly XInt Zero = new XInt(0);
        public static readonly XInt One = new XInt(1);

        #region 构造函数

        //内部使用，已经缩放完成的数据
        private XInt(long value)
        {
            scaledValue = value;
        }

        public XInt(int val)
        {
            scaledValue = val * MULTIPLIER_FACTOR;
        }

        public XInt(float val)
        {
            //float 转 long会有精度损失
            scaledValue = (long)Math.Round(val * MULTIPLIER_FACTOR);
        }

        //浮点数，float损失精度，必须显示转换
        public static explicit operator XInt(float f)
        {
            return new XInt((long)Math.Round(f * MULTIPLIER_FACTOR));
        }

        //int不损失精度，可以隐式转换
        public static implicit operator XInt(int i)
        {
            return new XInt(i);
        }

        #endregion

        //加减乘除取反

        #region 运算符

        public static XInt operator +(XInt a, XInt b)
        {
            return new XInt(a.scaledValue + b.scaledValue);
        }

        public static XInt operator -(XInt a, XInt b)
        {
            return new XInt(a.scaledValue - b.scaledValue);
        }

        public static XInt operator *(XInt a, XInt b)
        {
            //两个值都是左移了10位（乘以了1024后的结果）,所以要右移回去
            var value = a.scaledValue * b.scaledValue;
            if (value >= 0)
                value >>= BIT_MOVE_COUNT;
            else
                value = -(-value >> BIT_MOVE_COUNT);

            return new XInt(value);
        }

        public static XInt operator /(XInt a, XInt b)
        {
            if (b.scaledValue == 0)
                throw new Exception();

            return new XInt((a.scaledValue << BIT_MOVE_COUNT) / b.scaledValue);
        }

        public static XInt operator -(XInt value)
        {
            return new XInt(-value.scaledValue);
        }

        #endregion

        public static bool operator ==(XInt a, XInt b)
        {
            return a.scaledValue == b.scaledValue;
        }

        public static bool operator !=(XInt a, XInt b)
        {
            return a.scaledValue != b.scaledValue;
        }

        public static bool operator >(XInt a, XInt b)
        {
            return a.scaledValue > b.scaledValue;
        }

        public static bool operator <(XInt a, XInt b)
        {
            return a.scaledValue < b.scaledValue;
        }

        public static bool operator >=(XInt a, XInt b)
        {
            return a.scaledValue >= b.scaledValue;
        }

        public static bool operator <=(XInt a, XInt b)
        {
            return a.scaledValue <= b.scaledValue;
        }

        public static XInt operator >> (XInt value, int moveCount)
        {
            if (value.scaledValue >= 0)
                return new XInt(value.scaledValue >> moveCount);
            else
                return new XInt(-(-value.scaledValue >> moveCount));
        }

        public static XInt operator <<(XInt value, int moveCount)
        {
            return new XInt(value.scaledValue << moveCount);
        }

        /// <summary>
        /// 转换完成后，不可再参与逻辑运算
        /// </summary>
        public float RawFloat => scaledValue * 1.0f / MULTIPLIER_FACTOR;

        public int RawInt
        {
            get
            {
                if (scaledValue >= 0)
                    return (int)(scaledValue >> BIT_MOVE_COUNT);
                else
                    return -(int)(-scaledValue >> BIT_MOVE_COUNT);
            }
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
                return false;

            var vInt = (XInt)obj;
            return scaledValue == vInt.scaledValue;
        }

        public override int GetHashCode()
        {
            return scaledValue.GetHashCode();
        }

        public override string ToString()
        {
            return RawFloat.ToString();
        }
    }
}