﻿using System;
using System.Collections.Generic;

namespace RedPoint;

public class RedPointManager
{
    private static RedPointManager instance;

    private readonly Dictionary<string, RedPointData> _redPointMap = new();

    private RedPointManager()
    {
    }

    public static RedPointManager Instance
    {
        get
        {
            if (instance == null) instance = new RedPointManager();
            return instance;
        }
    }

    ///安全校验
    private void CheckRedPointExistence(string curRpName)
    {
        if (_redPointMap.ContainsKey(curRpName)) throw new Exception(curRpName + " 该红点已经被创建过");
    }

    ///获得对应红点数据（外界不可以直接持有红点数据并修改，一切行为都要由Manager去修改）
    private RedPointData GetRedPointByKey(string key)
    {
        return _redPointMap.ContainsKey(key) ? _redPointMap[key] : throw new Exception(key + "该红点不存在");
    }

    ///计算指定红点结果
    private void CalcRedPointByKey(string key, params object[] args)
    {
        var rp = GetRedPointByKey(key);
        rp.CalcRpCount(args);
    }

    #region 共有业务方法

    ///获得指定红点数量
    public int GetRedPointCountByKey(string key)
    {
        return GetRedPointByKey(key).GetCount();
    }

    ///获得指定红点状态
    public bool GetRedPointStatusByKey(string key)
    {
        return GetRedPointByKey(key).GetStatus();
    }

    #endregion


    #region 添加红点方法

    /// 添加红点，无父节点
    public void AddRedPoint(string curRpName)
    {
        CheckRedPointExistence(curRpName);
        _redPointMap.Add(curRpName, new RedPointData(curRpName));
    }

    public void AddRedPoint(string curRpName, Func<bool> call)
    {
        CheckRedPointExistence(curRpName);
        _redPointMap.Add(curRpName, new RedPointData(curRpName, null, call));
    }

    public void AddRedPoint(string curRpName, Func<int> call)
    {
        CheckRedPointExistence(curRpName);
        _redPointMap.Add(curRpName, new RedPointData(curRpName, null, call));
    }

    public void AddRedPoint<EventArgs>(string curRpName, Func<EventArgs, bool> call)
    {
        CheckRedPointExistence(curRpName);
        _redPointMap.Add(curRpName, new RedPointData(curRpName, null, call, true));
    }

    public void AddRedPoint<EventArgs>(string curRpName, Func<EventArgs, int> call)
    {
        CheckRedPointExistence(curRpName);
        _redPointMap.Add(curRpName, new RedPointData(curRpName, null, call, true));
    }

    /// 添加红点，指定父节点
    public void AddRedPoint(string curRpName, string parentName)
    {
        CheckRedPointExistence(curRpName);
        _redPointMap.Add(curRpName, new RedPointData(curRpName, GetRedPointByKey(parentName)));
    }

    public void AddRedPoint(string curRpName, string parentName, Func<bool> call)
    {
        CheckRedPointExistence(curRpName);
        _redPointMap.Add(curRpName, new RedPointData(curRpName, GetRedPointByKey(parentName), call));
    }

    public void AddRedPoint(string curRpName, string parentName, Func<int> call)
    {
        CheckRedPointExistence(curRpName);
        _redPointMap.Add(curRpName, new RedPointData(curRpName, GetRedPointByKey(parentName), call));
    }

    public void AddRedPoint<EventArgs>(string curRpName, string parentName, Func<EventArgs, bool> call)
    {
        CheckRedPointExistence(curRpName);
        _redPointMap.Add(curRpName, new RedPointData(curRpName, GetRedPointByKey(parentName), call, true));
    }

    public void AddRedPoint<EventArgs>(string curRpName, string parentName, Func<EventArgs, int> call)
    {
        CheckRedPointExistence(curRpName);
        _redPointMap.Add(curRpName, new RedPointData(curRpName, GetRedPointByKey(parentName), call, true));
    }

    #endregion
}