﻿namespace RedPoint;

public class RedPointArgs
{
}

public class RedPointTestArgs : RedPointArgs
{
   private int a = 0;
   private int b = 1;
}