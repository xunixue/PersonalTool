﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace RedPoint;

public class RedPointData
{
    private readonly Dictionary<string, RedPointData> _childDic = new();

    //事件监听
    private readonly List<EventDefine> _eventList = new();
    private readonly RedPointData _parent;
    private readonly bool haveParams;

    private readonly string Name;

    //RedPointManager对该委托进行了约束,只有两种返回类型 bool 或者 int
    private Delegate _calcRp;

    private int _pointNum;
    private bool _pointStatus;
    private int _selfPointNum;
    private bool _selfStatus;

    /// <summary>
    ///     红点初始化
    /// </summary>
    /// <param name="name">红点名</param>
    /// <param name="parent">父类名</param>
    /// <param name="cb">红点计算回调，Manager进行了方法约束</param>
    /// <exception cref="Exception"></exception>
    public RedPointData(string name, RedPointData parent = null, Delegate cb = null, bool needParams = false)
    {
        Name = name;
        if (parent != this)
        {
            _parent = parent;
            if (_parent != null)
                _parent.AddChild(this);
        }

        if (_calcRp != null)
            throw new Exception(Name + " 红点计算方法被覆盖");
        _calcRp = cb;
        haveParams = needParams;
        if (haveParams)
            CalcRpCount(null);
        else
            CalcRpCount();
    }

    ///添加字红点方法
    protected void AddChild(RedPointData child)
    {
        Console.WriteLine("添加子节点成功" + "   自己 : " + Name + "    子 : " + child.Name);
        _childDic[child.Name] = child;
    }

    /// 清除红点计算方法
    public void RemoveRpCalcFun()
    {
        _calcRp = null;
    }

    ///如果有参数，因为是C#强语言，所以参数一定要给默认值
    public void CalcRpCount(object args)
    {
        if (_calcRp != null)
            try
            {
                var result = _calcRp.DynamicInvoke(args);
                if (result is bool boolResult)
                {
                    if (_selfStatus != boolResult)
                    {
                        _selfStatus = boolResult;
                        UpdateStatus();
                        if (_parent != null) _parent.OnRedPointUpdate();
                    }
                }
                else if (result is int intResult)
                {
                    if (_selfPointNum != intResult)
                    {
                        _selfPointNum = intResult;
                        UpdateCount();
                        if (_parent != null) _parent.OnRedPointUpdate(true);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("报错红点名:" + Name + "  委托调用出现异常：" + ex.Message);
            }
    }

    public void CalcRpCount()
    {
        if (_calcRp != null)
            try
            {
                var result = _calcRp.DynamicInvoke();
                if (result is bool boolResult)
                {
                    if (_selfStatus != boolResult)
                    {
                        _selfStatus = boolResult;
                        UpdateStatus();
                        if (_parent != null) _parent.OnRedPointUpdate();
                    }
                }
                else if (result is int intResult)
                {
                    if (_selfPointNum != intResult)
                    {
                        _selfPointNum = intResult;
                        UpdateCount();
                        if (_parent != null) _parent.OnRedPointUpdate(true);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("报错红点名:" + Name + "  委托调用出现异常：" + ex.Message);
            }
    }

    public void OnRedPointUpdate(bool isCountChange = false)
    {
        if (isCountChange)
        {
            var oldCount = _pointNum;
            UpdateCount();
            if (oldCount != _pointNum && _parent != null)
                _parent.OnRedPointUpdate(true);
        }
        else
        {
            var oldStatus = _pointStatus;
            UpdateStatus();
            if (oldStatus != _pointStatus && _parent != null)
                _parent.OnRedPointUpdate();
        }
    }

    public int GetCount()
    {
        return _pointNum;
    }

    public bool GetStatus()
    {
        return _pointStatus || _pointNum > 0;
    }

    //添加事件监听
    public void AddEventListen(EventDefine eventDefine)
    {
        if (!_eventList.Contains(eventDefine)) _eventList.Add(eventDefine);
        if (haveParams) EventManager.AddListener<EventArgs>(eventDefine, CalcRpCount);
        else EventManager.AddListener(eventDefine, CalcRpCount);
    }

    //删除事件监听
    public void RemoveEventListen()
    {
        foreach (var define in _eventList)
            if (haveParams)
                EventManager.RemoveListener<EventArgs>(define, CalcRpCount);
            else
                EventManager.RemoveListener(define, CalcRpCount);
        _eventList.Clear();
    }

    #region 红点刷新

    private void UpdateStatus()
    {
        //子亮就直接出去
        _pointStatus = _selfStatus || _childDic.Values.Any(child => child._pointStatus);
    }

    private void UpdateCount()
    {
        var childPointNum = _childDic.Values.Sum(child => child._pointNum);
        _pointNum = _selfPointNum + childPointNum;
    }

    #endregion
}