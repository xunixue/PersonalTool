﻿namespace RedPoint;

public class EventArgs
{
}

public class IntEventArgs : EventArgs
{
    private int x;

    public IntEventArgs(int a)
    {
        x = a;
    }
}