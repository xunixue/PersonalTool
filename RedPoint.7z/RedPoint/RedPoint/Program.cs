﻿using System;
using RedPoint;

public class Program
{
    public delegate bool TestDelegate(int a);

    private static int i;

    public IntEventArgs Job;

    public static void Main()
    {
        /*Action<Tuple<string>> actionWithSingleParameter = (tuple) => Console.WriteLine($"Action with single parameter: {tuple.Item1}");
        Action<Tuple<int, string>> actionWithMultipleParameters = (tuple) => Console.WriteLine($"Action with multiple parameters: {tuple.Item1}, {tuple.Item2}");

        DoAction(actionWithSingleParameter, Tuple.Create("Hello"));
        DoAction(actionWithMultipleParameters, Tuple.Create(123, "World"));*/
        Test1();
    }


    public static void DoAction<T>(Action<T> action, T parameters)
    {
        /*if (action != null)
            action(parameters);
        else
            Console.WriteLine("Action is null");*/
    }

    public static void Test1()
    {
        RedPointManager.Instance.AddRedPoint(RedPointEnum.main);
        RedPointManager.Instance.AddRedPoint<IntEventArgs>(RedPointEnum.mid, RedPointEnum.main, Test);
        RedPointManager.Instance.AddRedPoint(RedPointEnum.child1, RedPointEnum.mid, Child1);
        //RedPointManager.Instance.AddRedPoint(RedPointEnum.child2, RedPointEnum.mid, Child2);
    }

    public static bool Test(IntEventArgs args)
    {
        if (args == null) return false;

        Console.WriteLine("进来了");
        if (i % 2 == 0)
        {
            i++;
            return true;
        }

        return false;
    }

    public static int Child1()
    {
        if (i % 3 == 0) return i;

        return 0;
    }

    public static bool Child2()
    {
        if (i == 4)
        {
            i++;
            return true;
        }

        return false;
    }
}