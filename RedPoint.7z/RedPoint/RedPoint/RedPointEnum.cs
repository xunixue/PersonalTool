﻿namespace RedPoint;

public class RedPointEnum
{
    public const string main = "Main";
    public const string mid = "Mid";
    public const string child1 = "child1";
    public const string child2 = "child2";
}