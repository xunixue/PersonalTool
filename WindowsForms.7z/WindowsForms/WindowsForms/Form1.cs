﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Diagnostics;

namespace WindowsForms
{
  public partial class Form1 : Form
  {
    private Triangle t;
    private Timer _timer;
    public Form1()
    {
      InitializeComponent();

      _timer = new Timer();
      _timer.Interval = 100;
      _timer.Tick += Timer_Tick;
      _timer.Start();
      
      Load += Form1_Load;
      Paint += Form1_Paint;
    }

    public void Form1_Paint(object sender, PaintEventArgs e)
    {
      e.Graphics.TranslateTransform(300,300);
      t.Draw(e.Graphics);
    }

     void Form1_Load(object sender,EventArgs e)
    {
      PointF A = new PointF(0,-200);
      PointF B = new PointF(200,200);
      PointF C = new PointF(-200, 200);
      t = new Triangle(A, B, C);
    }
     
    private void Timer_Tick(object sender, EventArgs e)
    {
      // 在计时器Tick事件中执行需要重复的逻辑
      // 例如更新UI、执行定时任务等
      t.Rotate(1);
      this.Invalidate();
    }
  }
}
