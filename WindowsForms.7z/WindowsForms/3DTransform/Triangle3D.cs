﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace _3DTransform
{
    public class Triangle3D
    {
        private Vector4 a, b, c;
        public Vector4 A, B, C;
        private bool callBack;

        private float dot;

        public Triangle3D()
        {
        }

        public Triangle3D(Vector4 a, Vector4 b, Vector4 c)
        {
            A = this.a = new Vector4(a);
            B = this.b = new Vector4(b);
            C = this.c = new Vector4(c);
        }

        //三角形利用矩阵的乘法进行变换
        public void Transform(Matrix4x4 m)
        {
            a = m.Mul(A);
            b = m.Mul(B);
            c = m.Mul(C);
        }

        public void CalculateLighting(Matrix4x4 _Object2World, Vector4 L)
        {
            Transform(_Object2World);
            var U = b - a;
            var V = c - a;
            var normal = U.Cross(V);
            dot = normal.Normalized.Dot(L.Normalized);
            dot = Math.Max(0, dot);

            var E = new Vector4(0, 0, -1, 0);
            callBack = normal.Normalized.Dot(E) < 0;
        }

        //绘制三角形到2D窗口上
        public void Draw(Graphics g, bool isLine)
        {
            if (isLine)
            {
                g.DrawLines(new Pen(Color.Red, 2), Get2DPointFAttr());
            }
            else
            {
                if (!callBack)
                {
                    var path = new GraphicsPath();
                    path.AddLines(Get2DPointFAttr());
                    var r = (int)(200 * dot) + 55;
                    var color = Color.FromArgb(r, r, r);
                    Brush br = new SolidBrush(color);
                    g.FillPath(br, path);
                }
            }
        }

        private PointF[] Get2DPointFAttr()
        {
            var arr = new PointF[4];
            arr[0] = Get2DPointF(a);
            arr[1] = Get2DPointF(b);
            arr[2] = Get2DPointF(c);
            arr[3] = arr[0];
            return arr;
        }

        private PointF Get2DPointF(Vector4 v)
        {
            var p = new PointF();
            p.X = (float)(v.x / v.w);
            p.Y = -(float)(v.y / v.w);
            return p;
        }
    }
}