﻿using System;
using System.Windows.Forms;

namespace _3DTransform
{
    public partial class Form1 : Form
    {
        private readonly Cube cube;
        private readonly Matrix4x4 m_projection;
        private readonly Matrix4x4 m_scale;
        private readonly Matrix4x4 m_view;
        private int a;
        private Matrix4x4 m_rotationX;
        private Matrix4x4 m_rotationY;
        private Matrix4x4 m_rotationZ;
        private Triangle3D t;

        public Form1()
        {
            InitializeComponent();

            m_rotationX = new Matrix4x4();
            m_rotationY = new Matrix4x4();
            m_rotationZ = new Matrix4x4();

            m_scale = new Matrix4x4();
            m_scale[1, 1] = 250;
            m_scale[2, 2] = 250;
            m_scale[3, 3] = 250;
            m_scale[4, 4] = 1;

            m_view = new Matrix4x4();
            m_view[1, 1] = 1;
            m_view[2, 2] = 1;
            m_view[3, 3] = 1;
            m_view[4, 3] = 250;
            m_view[4, 4] = 1;

            m_projection = new Matrix4x4();
            m_projection[1, 1] = 1;
            m_projection[2, 2] = 1;
            m_projection[3, 3] = 1;
            m_projection[3, 4] = 1.0 / 250;

            cube = new Cube();
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            var a = new Vector4(0, 0.5, 0, 1);
            var b = new Vector4(0.5, -0.5, 0, 1);
            var c = new Vector4(-0.5, -0.5, 0, 1);
            t = new Triangle3D(a, b, c);
        }

        private void Form1_Paint_1(object sender, PaintEventArgs e)
        {
            //t.Draw(e.Graphics);
            cube.Draw(e.Graphics, cbLine.Checked);
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            m_view[4, 3] = ((TrackBar)sender).Value;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            a += 2;
            var angle = a / 360f * Math.PI;
            //X
            m_rotationX[1, 1] = 1;
            m_rotationX[2, 2] = Math.Cos(angle);
            m_rotationX[2, 3] = Math.Sin(angle);
            m_rotationX[3, 2] = -Math.Sin(angle);
            m_rotationX[3, 3] = Math.Cos(angle);
            m_rotationX[4, 4] = 1;
            //Y
            m_rotationY[1, 1] = Math.Cos(angle);
            m_rotationY[1, 3] = Math.Sin(angle);
            m_rotationY[2, 2] = 1;
            m_rotationY[3, 1] = -Math.Sin(angle);
            m_rotationY[3, 3] = Math.Cos(angle);
            m_rotationY[4, 4] = 1;
            //Z
            m_rotationZ[1, 1] = Math.Cos(angle);
            m_rotationZ[1, 2] = Math.Sin(angle);
            m_rotationZ[2, 1] = -Math.Sin(angle);
            m_rotationZ[2, 2] = Math.Cos(angle);
            m_rotationZ[3, 3] = 1;
            m_rotationZ[4, 4] = 1;

            //转置判断 
            if (cbX.Checked)
            {
                var tx = m_rotationX.Transpose();
                m_rotationX = m_rotationX.Mul(tx);
            }

            if (cbY.Checked)
            {
                var ty = m_rotationY.Transpose();
                m_rotationY = m_rotationY.Mul(ty);
            }

            if (cbZ.Checked)
            {
                var tz = m_rotationZ.Transpose();
                m_rotationZ = m_rotationZ.Mul(tz);
            }

            var mall = m_rotationX.Mul(m_rotationY.Mul(m_rotationZ));

            //模型到世界     
            var m = m_scale.Mul(mall);

            //t.CalculateLighting(m, new Vector4(-1, 1, -1, 0));
            cube.CalculateLighting(m, new Vector4(-1, 1, -1, 0));

            //世界到视图 mv
            var mv = m.Mul(m_view);
            //视图到投影 mvp
            var mvp = mv.Mul(m_projection);

            //t.Transform(mvp);
            cube.Transform(mvp);

            Invalidate();
        }
    }
}