﻿using System;

namespace _3DTransform
{
    public class Vector4
    {
        public double x, y, z, w;

        public Vector4()
        {
        }

        public Vector4(double x, double y, double z, double w)
        {
            this.x = x;
            this.y = y;
            this.z = z;
            this.w = w;
        }

        public Vector4(Vector4 v)
        {
            x = v.x;
            y = v.y;
            z = v.z;
            w = v.w;
        }

        public Vector4 Normalized
        {
            get
            {
                var Mod = Math.Sqrt(x * x + y * y + z * z);
                return new Vector4(x / Mod, y / Mod, z / Mod, w / Mod);
            }
        }

        public static Vector4 operator -(Vector4 a, Vector4 b)
        {
            return new Vector4(a.x - b.x, a.y - b.y, a.z - b.z, a.w - b.w);
        }

        public Vector4 Cross(Vector4 v)
        {
            return new Vector4(y * v.z - z * v.y, z * v.x - x * v.z, x * v.y - y * v.x, 0);
        }

        public float Dot(Vector4 v)
        {
            return (float)(x * v.x + y * v.y + z * v.z);
        }
    }
}