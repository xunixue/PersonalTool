﻿namespace _3DTransform
{
    public class Matrix4x4
    {
        private readonly double[,] pts;

        public Matrix4x4()
        {
            pts = new double[4, 4];
        }

        public double this[int i, int j]
        {
            get => pts[i - 1, j - 1];
            set => pts[i - 1, j - 1] = value;
        }

        public Matrix4x4 Mul(Matrix4x4 m)
        {
            var newM = new Matrix4x4();
            for (var w = 1; w <= 4; w++)
            for (var h = 1; h <= 4; h++)
            for (var n = 1; n <= 4; n++)
                newM[w, h] += this[w, n] * m[n, h];

            return newM;
        }

        public Vector4 Mul(Vector4 v)
        {
            var newV = new Vector4();
            newV.x = v.x * this[1, 1] + v.y * this[2, 1] + v.z * this[3, 1] + v.w * this[4, 1];
            newV.y = v.x * this[1, 2] + v.y * this[2, 2] + v.z * this[3, 2] + v.w * this[4, 2];
            newV.z = v.x * this[1, 3] + v.y * this[2, 3] + v.z * this[3, 3] + v.w * this[4, 3];
            newV.w = v.x * this[1, 4] + v.y * this[2, 4] + v.z * this[3, 4] + v.w * this[4, 4];

            return newV;
        }

        public Matrix4x4 Transpose()
        {
            var t = new Matrix4x4();
            for (var i = 1; i <= 4; i++)
            for (var j = 1; j <= 4; j++)
                t[i, j] = this[j, i];
            return t;
        }
    }
}