﻿using System;

namespace LogUtils
{
    ///日志配置
    public enum LogColor
    {
        None,
        Red,
        Green,
        Blue,
        Cyan,
        Magenta,
        Yellow
    }

    public enum LoggerType
    {
        Unity,
        Console
    }

    public class LogConfig
    {
        public bool enableLog = true; //是否需要打印
        public string logPrefix = "#"; //前缀
        public bool enableTime = true; //是否显示时间
        public string logSeparate = ">>"; //分隔符
        public bool enableThreadID = true; //是否显示线程id
        public bool enableTrace = true; //是否显示具体堆栈消息
        public bool enableSave = true; //是否需要保存
        public bool enableCover = true; //是否需要覆盖对应文件
        public string savePath = string.Format("{0}Logs\\", AppDomain.CurrentDomain.BaseDirectory); //保存根文件目录
        public string saveName = "ConsolePELog.txt";
        public LoggerType loggerType = LoggerType.Console;
    }

    internal interface ILogger
    {
        void Log(string msg, LogColor logColor = LogColor.None);
        void Warn(string msg);
        void Error(string msg);
    }
}