﻿using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Threading;

public static class ExtensionMethods
{
    public static void Log(this object obj, string log, params object[] args)
    {
        LogUtils.XLog.Log(string.Format(log, args));
    }

    public static void Log(this object obj, object log)
    {
        LogUtils.XLog.Log(log);
    }

    public static void ColorLog(this object obj, LogUtils.LogColor color, string log, params object[] args)
    {
        LogUtils.XLog.ColorLog(color, string.Format(log, args));
    }

    public static void ColorLog(this object obj, LogUtils.LogColor color, object log)
    {
        LogUtils.XLog.ColorLog(color, log);
    }

    public static void Trace(this object obj, string log, params object[] args)
    {
        LogUtils.XLog.Trace(string.Format(log, args));
    }

    public static void Trace(this object obj, object log)
    {
        LogUtils.XLog.Trace(log);
    }

    public static void Warn(this object obj, string log, params object[] args)
    {
        LogUtils.XLog.Warn(string.Format(log, args));
    }

    public static void Warn(this object obj, object log)
    {
        LogUtils.XLog.Warn(log);
    }

    public static void Error(this object obj, string log, params object[] args)
    {
        LogUtils.XLog.Error(string.Format(log, args));
    }

    public static void Error(this object obj, object log)
    {
        LogUtils.XLog.Error(log);
    }
}

namespace LogUtils
{
    public static class XLog
    {
        private class UnityLogger : ILogger
        {
            private Type type = Type.GetType("UnityEngine.Debug, UnityEngine");

            public void Log(string msg, LogColor logColor = LogColor.None)
            {
                if (logColor != LogColor.None)
                    msg = ColorUnityLog(msg, logColor);

                type.GetMethod("Log", new Type[] { typeof(object) })?.Invoke(null, new object[] { msg });
            }

            public void Warn(string msg)
            {
                type.GetMethod("LogWarning", new Type[] { typeof(object) })?.Invoke(null, new object[] { msg });
            }

            public void Error(string msg)
            {
                type.GetMethod("LogError", new Type[] { typeof(object) })?.Invoke(null, new object[] { msg });
            }

            private string ColorUnityLog(string msg, LogColor color)
            {
                switch (color)
                {
                    case LogColor.Red:
                        msg = string.Format("<color=#FF0000>{0}</color>", msg);
                        break;
                    case LogColor.Green:
                        msg = string.Format("<color=#00FF00>{0}</color>", msg);
                        break;
                    case LogColor.Blue:
                        msg = string.Format("<color=#0000FF>{0}</color>", msg);
                        break;
                    case LogColor.Cyan:
                        msg = string.Format("<color=#00FFFF>{0}</color>", msg);
                        break;
                    case LogColor.Magenta:
                        msg = string.Format("<color=#FF00FF>{0}</color>", msg);
                        break;
                    case LogColor.Yellow:
                        msg = string.Format("<color=#FFFF00>{0}</color>", msg);
                        break;
                    case LogColor.None:
                    default:
                        break;
                }

                return msg;
            }
        }

        private class ConsoleLogger : ILogger
        {
            public void Log(string msg, LogColor logColor = LogColor.None)
            {
                WriteConsoleLog(msg, logColor);
            }

            public void Warn(string msg)
            {
                WriteConsoleLog(msg, LogColor.Yellow);
            }

            public void Error(string msg)
            {
                WriteConsoleLog(msg, LogColor.Red);
            }

            private void WriteConsoleLog(string msg, LogColor color)
            {
                switch (color)
                {
                    case LogColor.Red:
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine(msg);
                        Console.ForegroundColor = ConsoleColor.Gray;
                        break;
                    case LogColor.Green:
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(msg);
                        Console.ForegroundColor = ConsoleColor.Gray;
                        break;
                    case LogColor.Blue:
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.WriteLine(msg);
                        Console.ForegroundColor = ConsoleColor.Gray;
                        break;
                    case LogColor.Cyan:
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.WriteLine(msg);
                        Console.ForegroundColor = ConsoleColor.Gray;
                        break;
                    case LogColor.Magenta:
                        Console.ForegroundColor = ConsoleColor.Magenta;
                        Console.WriteLine(msg);
                        Console.ForegroundColor = ConsoleColor.Gray;
                        break;
                    case LogColor.Yellow:
                        Console.ForegroundColor = ConsoleColor.DarkYellow;
                        Console.WriteLine(msg);
                        Console.ForegroundColor = ConsoleColor.Gray;
                        break;
                    case LogColor.None:
                    default:
                        Console.WriteLine(msg);
                        break;
                }
            }
        }

        public static LogConfig cfg;
        private static ILogger logger;
        private static StreamWriter LogFileWriter = null;

        public static void InitSettings(LogConfig config = null)
        {
            if (config == null)
                cfg = new LogConfig();
            else
                cfg = config;

            if (cfg.loggerType == LoggerType.Console)
                logger = new ConsoleLogger();
            else
                logger = new UnityLogger();

            if (cfg.enableSave == false)
                return;

            if (cfg.enableCover)
            {
                var path = cfg.savePath + cfg.saveName;
                try
                {
                    if (Directory.Exists(cfg.savePath))
                    {
                        if (File.Exists(path))
                            File.Delete(path);
                    }
                    else
                    {
                        Directory.CreateDirectory(cfg.savePath);
                    }

                    LogFileWriter = File.AppendText(path);
                    LogFileWriter.AutoFlush = true;
                }
                catch
                {
                    LogFileWriter = null;
                }
            }
            else
            {
                var prefix = DateTime.Now.ToString("yyyyMMdd@HH-mm-ss");
                var path = cfg.savePath + prefix + cfg.saveName;
                try
                {
                    if (Directory.Exists(cfg.savePath) == false)
                        Directory.CreateDirectory(cfg.savePath);
                    LogFileWriter = File.AppendText(path);
                    LogFileWriter.AutoFlush = true;
                }
                catch
                {
                    LogFileWriter = null;
                }
            }
        }

        #region DebugLog

        public static void Log(string msg, params object[] args)
        {
            if (cfg.enableLog == false)
                return;
            msg = DecorateLog(string.Format(msg, args));
            logger.Log(msg);
            if (cfg.enableSave)
                WriteToFile($"[L]{msg}");
        }

        public static void Log(object obj)
        {
            if (cfg.enableLog == false)
                return;
            var msg = DecorateLog(obj.ToString());
            logger.Log(msg);
            if (cfg.enableSave)
                WriteToFile($"[L]{msg}");
        }

        public static void ColorLog(LogColor color, string msg, params object[] args)
        {
            if (cfg.enableLog == false)
                return;
            msg = DecorateLog(string.Format(msg, args));
            logger.Log(msg, color);
            if (cfg.enableSave)
                WriteToFile($"[L]{msg}");
        }

        public static void ColorLog(LogColor color, object obj)
        {
            if (cfg.enableLog == false)
                return;
            var msg = DecorateLog(obj.ToString());
            logger.Log(msg, color);
            if (cfg.enableSave)
                WriteToFile($"[L]{msg}");
        }

        public static void Trace(string msg, params object[] args)
        {
            if (cfg.enableLog == false)
                return;
            msg = DecorateLog(string.Format(msg, args), true);
            logger.Log(msg, LogColor.Magenta);
            if (cfg.enableSave)
                WriteToFile($"[T]{msg}");
        }

        public static void Trace(object obj)
        {
            if (cfg.enableLog == false)
                return;
            var msg = DecorateLog(obj.ToString(), true);
            logger.Log(msg, LogColor.Magenta);
            if (cfg.enableSave)
                WriteToFile($"[T]{msg}");
        }

        public static void Warn(string msg, params object[] args)
        {
            if (cfg.enableLog == false)
                return;
            msg = DecorateLog(string.Format(msg, args));
            logger.Warn(msg);
            if (cfg.enableSave)
                WriteToFile($"[L]{msg}");
        }

        public static void Warn(object obj)
        {
            if (cfg.enableLog == false)
                return;
            var msg = DecorateLog(obj.ToString());
            logger.Warn(msg);
            if (cfg.enableSave)
                WriteToFile($"[L]{msg}");
        }

        public static void Error(string msg, params object[] args)
        {
            if (cfg.enableLog == false)
                return;
            msg = DecorateLog(string.Format(msg, args), true);
            logger.Error(msg);
            if (cfg.enableSave)
                WriteToFile($"[L]{msg}");
        }

        public static void Error(object obj)
        {
            if (cfg.enableLog == false)
                return;
            var msg = DecorateLog(obj.ToString(), true);
            logger.Error(msg);
            if (cfg.enableSave)
                WriteToFile($"[L]{msg}");
        }

        #endregion

        #region Tools

        private static string DecorateLog(string msg, bool isTrace = false)
        {
            var sb = new StringBuilder(cfg.logPrefix, 100);
            if (cfg.enableTime)
                sb.AppendFormat(" {0}", DateTime.Now.ToString("hh:mm:ss--fff"));
            if (cfg.enableThreadID)
                sb.AppendFormat(" {0}", GetThreadID());
            sb.AppendFormat(" {0} {1}", cfg.logSeparate, msg);
            if (isTrace)
                sb.AppendFormat(" \nStackTrace: {0}", GETLogTrace());
            return sb.ToString();
        }

        private static string GetThreadID()
        {
            return string.Format(" ThreadID: {0}", Thread.CurrentThread.ManagedThreadId);
        }

        private static string GETLogTrace()
        {
            var st = new StackTrace(3, true);

            var traceInfo = "";
            for (var i = 0; i < st.FrameCount; i++)
            {
                var sf = st.GetFrame(i);
                traceInfo += string.Format("\n    {0}::{1} line: {2}", sf.GetFileName(), sf.GetMethod(), sf.GetFileLineNumber());
            }

            return traceInfo;
        }

        private static void WriteToFile(string msg)
        {
            if (LogFileWriter != null)
                try
                {
                    LogFileWriter.Write(msg);
                }
                catch
                {
                    LogFileWriter = null;
                }
        }

        #endregion
    }
}