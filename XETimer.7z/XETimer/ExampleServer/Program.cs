﻿using LogUtils;
using XETimer;

namespace ConsoleApp1;

internal class Program
{
    private static void Main(string[] args)
    {
        XLog.InitSettings();

        XLog.ColorLog("hello", LogColor.Green);
        //TickTimerExample();
        //AsyncTimerExample();
        FrameTimerExample();

        Console.ReadKey();
    }

    private static void TickTimerExample()
    {
        var timer = new TickTimer(10, false)
        {
            LogFunc = XLog.Log,
            WarnFunc = XLog.Warn,
            ErrorFunc = XLog.Error
        };

        uint interver = 66;
        var count = 0;
        var sum = 0;
        var taskID = 0;

        Task.Run(async () =>
        {
            await Task.Delay(2000);
            var historyTime = DateTime.UtcNow;
            taskID = timer.AddTask(
                interver,
                tid =>
                {
                    var nowTime = DateTime.UtcNow;
                    var ts = nowTime - historyTime;
                    historyTime = nowTime;
                    var delta = (int)(ts.TotalMilliseconds - interver);
                    XLog.ColorLog($"间隔差:{delta}", LogColor.Yellow);

                    sum += Math.Abs(delta);
                    XLog.ColorLog("tid:{0} work.", LogColor.Magenta, tid);
                },
                tid => { XLog.ColorLog("tid:{0} cancel.", LogColor.Magenta, tid); },
                count);
        });

        Task.Run(async () =>
        {
            XLog.Log("Handle Start");
            while (true)
                //timer.UpdateTask();
                //timer.HandleTask();
                await Task.Delay(2);
        });

        while (true)
        {
            var ipt = Console.ReadLine();
            if (ipt == "calc")
                XLog.ColorLog("平均间隔：" + sum * 1.0f / count, LogColor.Red);
            else if
                (ipt == "del") timer.DeleteTask(taskID);
        }
    }

    private static void AsyncTimerExample()
    {
        var timer = new AsyncTimer(false)
        {
            LogFunc = XLog.Log,
            WarnFunc = XLog.Warn,
            ErrorFunc = XLog.Error
        };

        uint interver = 66;
        var count = 0;
        var sum = 0;
        var taskID = 0;

        Task.Run(async () =>
        {
            await Task.Delay(2000);
            var historyTime = DateTime.UtcNow;
            taskID = timer.AddTask(
                interver,
                tid =>
                {
                    var nowTime = DateTime.UtcNow;
                    var ts = nowTime - historyTime;
                    historyTime = nowTime;
                    var delta = (int)(ts.TotalMilliseconds - interver);
                    XLog.ColorLog($"间隔差:{delta}", LogColor.Yellow);

                    sum += Math.Abs(delta);
                    XLog.ColorLog("tid:{0} work.", LogColor.Magenta, tid);
                },
                tid => { XLog.ColorLog("tid:{0} cancel.", LogColor.Magenta, tid); },
                count);
        });

        Task.Run(async () =>
        {
            XLog.Log("Handle Start");
            while (true)
                //timer.HandleTask();
                Thread.Sleep(5);
        });

        while (true)
        {
            var ipt = Console.ReadLine();
            if (ipt == "calc")
                XLog.ColorLog("平均间隔：" + sum * 1.0f / count, LogColor.Red);
            else if
                (ipt == "del") timer.DeleteTask(taskID);
        }
    }

    private static void FrameTimerExample()
    {
        var timer = new FrameTimer(100)
        {
            LogFunc = XLog.Log,
            WarnFunc = XLog.Warn,
            ErrorFunc = XLog.Error
        };

        var count = 5;
        var sum = 0;
        var taskID = 0;

        Task.Run(async () =>
        {
            await Task.Delay(2000);
            taskID = timer.AddTask(
                10,
                tid => { XLog.ColorLog("tid:{0} work.", LogColor.Magenta, tid); },
                tid => { XLog.ColorLog("tid:{0} cancel.", LogColor.Magenta, tid); },
                count);
        });

        Task.Run(async () =>
        {
            while (true)
            {
                timer.UpdateTask();
                Thread.Sleep(66);
            }
        });

        while (true)
        {
            var ipt = Console.ReadLine();
            if (ipt == "calc")
                XLog.ColorLog("平均间隔：" + sum * 1.0f / count, LogColor.Red);
            else if
                (ipt == "del") timer.DeleteTask(taskID);
        }
    }
}