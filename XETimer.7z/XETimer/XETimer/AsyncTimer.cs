﻿//使用Async await语法驱动，运行在线程池中，可以设置多线程或主线程回调任务

using System.Collections.Concurrent;

namespace XETimer;

public class AsyncTimer : XETimer
{
    private class AsyncTaskPack
    {
        public int tid;
        public Action<int> cb;

        public AsyncTaskPack(int tid, Action<int> cb)
        {
            this.tid = tid;
            this.cb = cb;
        }
    }

    private bool setHandle;
    private readonly ConcurrentDictionary<int, AsyncTask> taskDic;
    private ConcurrentQueue<AsyncTaskPack> packQue;
    private const string tidLock = "AsyncTimer_tidLock";

    public AsyncTimer(bool setHandle = false)
    {
        taskDic = new ConcurrentDictionary<int, AsyncTask>();
        this.setHandle = setHandle;
        if (setHandle)
            packQue = new ConcurrentQueue<AsyncTaskPack>();
    }

    public override int AddTask(uint delay, Action<int> taskCB, Action<int> cancelCB, int count = 1)
    {
        var tid = GenerateTid();
        var task = new AsyncTask(tid, delay, count, taskCB, cancelCB);
        RunTaskInPool(task);

        if (taskDic.TryAdd(tid, task))
            return tid;

        WarnFunc?.Invoke($"Key: {tid} already exist.");
        return -1;
    }

    public override bool DeleteTask(int taskID)
    {
        if (taskDic.TryRemove(tid, out var task))
        {
            LogFunc?.Invoke($"Remove tid:{task.tid} task in taskDic Succ.");

            task.cts.Cancel();
            if (setHandle && task.cancelCB != null)
                packQue.Enqueue(new AsyncTaskPack(task.tid, task.cancelCB));
            else
                task.cancelCB?.Invoke(task.tid);

            return true;
        }
        else
        {
            ErrorFunc?.Invoke($"Remove tid:{task.tid} task in taskDic failed");
            return false;
        }
    }

    public override void Reset()
    {
        if (packQue != null && !packQue.IsEmpty)
            WarnFunc?.Invoke("Call Queue is not Empty");
        taskDic.Clear();
        tid = 0;
    }

    public void HandleTask()
    {
        while (packQue != null && packQue.Count > 0)
            if (packQue.TryDequeue(out var pack))
                pack.cb?.Invoke(pack.tid);
            else
                WarnFunc?.Invoke($"packQue dequeue data failed.");
    }

    private void RunTaskInPool(AsyncTask task)
    {
        Task.Run(async () =>
        {
            if (task.count > 0)
                do
                {
                    //限定次数的循环任务
                    --task.count;
                    ++task.loopIndex;
                    var delay = (int)task.delay + task.fixDelta;
                    if (delay > 0)
                        await Task.Delay(delay, task.ct);
                    var ts = DateTime.UtcNow - task.startTime;
                    task.fixDelta = (int)(task.delay * task.loopIndex - ts.TotalMilliseconds);
                    CallBackTaskCB(task);
                } while (task.count > 0);
            else
                //无限循环任务
                while (true)
                {
                    ++task.loopIndex;
                    var delay = (int)task.delay + task.fixDelta;
                    if (delay > 0)
                        await Task.Delay(delay, task.ct);
                    var ts = DateTime.UtcNow - task.startTime;
                    task.fixDelta = (int)(task.delay * task.loopIndex - ts.TotalMilliseconds);
                    CallBackTaskCB(task, true);
                }
        });
    }

    private void CallBackTaskCB(AsyncTask task, bool isLoop = false)
    {
        if (setHandle)
            packQue.Enqueue(new AsyncTaskPack(task.tid, task.taskCB));
        else
            task.taskCB.Invoke(task.tid);

        if (!isLoop && task.count == 0)
        {
            if (taskDic.TryRemove(task.tid, out var temp))
                LogFunc?.Invoke($"Task tid:{task.tid} run to completion.");
            else
                ErrorFunc?.Invoke($"Remove tid:{task.tid} task in taskDic failed.");
        }
    }

    protected override int GenerateTid()
    {
        lock (tidLock)
        {
            while (true)
            {
                ++tid;
                if (tid == int.MaxValue)
                    tid = 0;
                if (!taskDic.ContainsKey(tid))
                    return tid;
            }
        }
    }

    private class AsyncTask
    {
        public int tid;
        public uint delay;
        public int count;

        public DateTime startTime; //开始时间
        public ulong loopIndex; //循环次数
        public int fixDelta;

        public Action<int> taskCB;
        public Action<int> cancelCB;

        public CancellationTokenSource cts;
        public CancellationToken ct;

        public AsyncTask(int tid, uint delay, int count, Action<int> taskCB, Action<int> cancelCB)
        {
            this.tid = tid;
            this.delay = delay;
            this.count = count;
            this.taskCB = taskCB;
            this.cancelCB = cancelCB;
            startTime = DateTime.UtcNow;
            loopIndex = 0;
            fixDelta = 0;

            cts = new CancellationTokenSource();
            ct = cts.Token;
        }
    }
}