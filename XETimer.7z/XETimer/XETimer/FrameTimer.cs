﻿//使用外部帧循环调用驱动，并在帧循环中回调

using System.Collections.Concurrent;

namespace XETimer;

public class FrameTimer : XETimer
{
    private class FrameTaskPack
    {
        public int tid;
        public Action<int> cb;

        public FrameTaskPack(int tid, Action<int> cb)
        {
            this.tid = tid;
            this.cb = cb;
        }
    }

    private ulong currentFrame;
    private readonly Dictionary<int, FrameTask> taskDic;
    private Queue<FrameTaskPack> packQue;
    private const string tidLock = "FrameTimer_tidLock";
    private List<int> tidList;

    public FrameTimer(ulong frameID = 0)
    {
        currentFrame = frameID;
        taskDic = new Dictionary<int, FrameTask>();
        tidList = new List<int>();
    }

    public override int AddTask(uint delay, Action<int> taskCB, Action<int> cancelCB, int count = 1)
    {
        var tid = GenerateTid();
        var destFrame = currentFrame + delay;
        var task = new FrameTask(tid, delay, count, destFrame, taskCB, cancelCB);
        if (taskDic.ContainsKey(tid))
        {
            WarnFunc?.Invoke($"Key:{tid} already exist.");
            return -1;
        }
        else
        {
            taskDic.Add(tid, task);
            return tid;
        }
    }

    public override bool DeleteTask(int taskID)
    {
        if (taskDic.TryGetValue(tid, out var task))
        {
            if (taskDic.Remove(tid))
            {
                task.cancelCB?.Invoke(tid);
                return true;
            }
            else
            {
                ErrorFunc?.Invoke($"Remove tid:{tid} in taskDic failed.");
                return false;
            }
        }
        else
        {
            WarnFunc?.Invoke($"tid:{tid} is not exist.");
            return false;
        }
    }

    public override void Reset()
    {
        taskDic.Clear();
        tidList.Clear();
        currentFrame = 0;
    }

    public void UpdateTask()
    {
        ++currentFrame;
        tidList.Clear();

        foreach (var item in taskDic)
        {
            var task = item.Value;
            if (task.destFrame <= currentFrame)
            {
                task.taskCB.Invoke(task.tid);
                task.destFrame += task.delay;
                --task.count;
                if (task.count == 0)
                    tidList.Add(task.tid);
            }
        }

        for (var i = 0; i < tidList.Count; i++)
            if (taskDic.Remove(tidList[i]))
                LogFunc?.Invoke($"Task tid:{tid} run to completion");
            else
                ErrorFunc?.Invoke($"Remove tid:{tidList[i]} task in taskDic failed.");
    }

    protected override int GenerateTid()
    {
        lock (tidLock)
        {
            while (true)
            {
                ++tid;
                if (tid == int.MaxValue)
                    tid = 0;
                if (!taskDic.ContainsKey(tid))
                    return tid;
            }
        }
    }

    private class FrameTask
    {
        public int tid;
        public uint delay;
        public int count;

        public ulong destFrame;

        public Action<int> taskCB;
        public Action<int> cancelCB;

        public FrameTask(int tid, uint delay, int count, ulong destFrame, Action<int> taskCB, Action<int> cancelCB)
        {
            this.tid = tid;
            this.delay = delay;
            this.count = count;
            this.destFrame = destFrame;
            this.taskCB = taskCB;
            this.cancelCB = cancelCB;
        }
    }
}