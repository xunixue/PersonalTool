﻿//毫秒级景区的定时器

using System.Collections.Concurrent;

namespace XETimer;

public class TickTimer : XETimer
{
    private class TickTaskPack
    {
        public int tid;
        public Action<int> cb;

        public TickTaskPack(int tid, Action<int> cb)
        {
            this.tid = tid;
            this.cb = cb;
        }
    }

    private readonly DateTime startDateTime = new(1970, 1, 1, 0, 0, 0, 0);
    private readonly ConcurrentDictionary<int, TickTask> taskDic;
    private readonly bool setHandle;
    private readonly ConcurrentQueue<TickTaskPack> packQue;
    private const string tidLock = "TickTimer_tidLock";

    private readonly Thread timerThread;

    public TickTimer(int interval = 0, bool setHandle = false)
    {
        taskDic = new ConcurrentDictionary<int, TickTask>();
        this.setHandle = setHandle;
        if (setHandle)
            packQue = new ConcurrentQueue<TickTaskPack>();

        if (interval != 0)
        {
            void StartTick()
            {
                try
                {
                    while (true)
                    {
                        UpdateTask();
                        Thread.Sleep(interval);
                    }
                }
                catch (ThreadAbortException e)
                {
                    WarnFunc?.Invoke($"Tick Thread Abort: {e}.");
                }
            }

            //cts = new CancellationTokenSource();
            timerThread = new Thread(StartTick);
            //.net 8.0
            //timerThread.Start(cts.Token);
            timerThread.Start();
        }
    }

    public override int AddTask(uint delay, Action<int> taskCB, Action<int> cancelCB, int count = 1)
    {
        var tid = GenerateTid();
        var startTime = GetUTCMilliseconds();
        var destTime = startTime + delay;
        var task = new TickTask(tid, delay, count, startTime, destTime, taskCB, cancelCB);
        if (taskDic.TryAdd(tid, task)) return tid;

        WarnFunc?.Invoke($"Key: {tid} already exist.");
        return -1;
    }

    public override bool DeleteTask(int tid)
    {
        if (taskDic.TryRemove(tid, out var task))
        {
            if (setHandle && task.cancelCB != null)
            {
                packQue.Enqueue(new TickTaskPack(tid, task.cancelCB));
            }
            else
            {
                task.cancelCB?.Invoke(tid);
                return true;
            }
        }

        WarnFunc?.Invoke($"Key: {tid} remove exist.");
        return false;
    }

    public override void Reset()
    {
        if (!packQue.IsEmpty)
            WarnFunc?.Invoke("Callback Queue is not Empty.");
        taskDic.Clear();
        if (timerThread != null)
            //abort在高.net版本已经不推荐使用了
            timerThread.Abort();
        //.net 8.0
        //cts.Cancel();
    }

    public void UpdateTask()
    {
        var nowTime = GetUTCMilliseconds();
        foreach (var item in taskDic)
        {
            var task = item.Value;
            if (nowTime < task.destTime)
                continue;

            ++task.loopIndex;

            if (task.count > 0)
            {
                --task.count;
                if (task.count == 0)
                {
                    FinishTask(task.tid);
                }
                else
                {
                    task.destTime = task.startTime + task.delay * (task.loopIndex + 1);
                    CallTaskCB(task.tid, task.taskCB);
                }
            }
            else
            {
                task.destTime = task.startTime + task.delay * (task.loopIndex + 1);
                CallTaskCB(task.tid, task.taskCB);
            }
        }
    }

    public void HandleTask()
    {
        while (packQue != null && packQue.Count > 0)
            if (packQue.TryDequeue(out var pack))
                pack.cb.Invoke(pack.tid);
            else
                ErrorFunc?.Invoke("packQue Dequeue Data Error.");
    }

    private void FinishTask(int tid)
    {
        //线程安全字典，遍历过程中删除无影响
        if (taskDic.TryRemove(tid, out var task))
        {
            CallTaskCB(task.tid, task.taskCB);
            task.taskCB = null;
        }
        else
        {
            WarnFunc?.Invoke($"Key: {tid} remove exist.");
        }
    }

    private void CallTaskCB(int tid, Action<int> taskCB)
    {
        if (setHandle)
            packQue.Enqueue(new TickTaskPack(tid, taskCB));
        else
            taskCB.Invoke(tid);
    }

    private double GetUTCMilliseconds()
    {
        var ts = DateTime.UtcNow - startDateTime;
        return ts.TotalMilliseconds;
    }

    protected override int GenerateTid()
    {
        lock (tidLock)
        {
            while (true)
            {
                ++tid;
                if (tid == int.MaxValue)
                    tid = 0;
                if (!taskDic.ContainsKey(tid))
                    return tid;
            }
        }
    }

    private class TickTask
    {
        public int tid;
        public uint delay;
        public int count;

        public double destTime; //结束时间
        public double startTime; //开始时间
        public ulong loopIndex; //循环次数

        public Action<int> taskCB;
        public Action<int> cancelCB;

        public TickTask(int tid, uint delay, int count, double startTime, double destTime, Action<int> taskCB, Action<int> cancelCB)
        {
            this.tid = tid;
            this.delay = delay;
            this.count = count;
            this.destTime = destTime;
            this.taskCB = taskCB;
            this.cancelCB = cancelCB;
            this.startTime = startTime;
            loopIndex = 0;
        }
    }
}